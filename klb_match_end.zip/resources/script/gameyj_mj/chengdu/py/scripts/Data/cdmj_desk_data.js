var RoomMgr = require('jlmj_room_mgr').RoomMgr;
var base_mj_desk_data = require("new_mj_desk_data");

var CDMJDeskData = cc.Class({
    extends: base_mj_desk_data.DeskData,

    statics: {

        Instance: function () {
            if (!this.s_desk) {
                this.s_desk = new CDMJDeskData();
            }
            return this.s_desk;
        },

        Destroy: function () {
            if (this.s_desk) {
                this.s_desk.clear();
                this.s_desk = null;
            }
        },

    },

    ctor: function () {
        this.notBackToLobby = false;
        this.noCDAudio = false;
    },
    clear: function () {
        this._super();

        this.is_genzhuang = false;
        this.notBackToLobby = false;
        this.noCDAudio = false;
        this.jiesuanData = null;
    },
    /**
     * 是否还有剩余牌
     * @returns {boolean}
     */
    hasRemainPai: function () {
        return this.remainCards > 0;
    },

    getMJRemainCard(){
        if(RoomMgr.Instance()._Rule){
            if(RoomMgr.Instance()._Rule.usercountlimit == 4){
                return 108;
            }else{
                return RoomMgr.Instance()._Rule.issanfang ? 108 : 71;
            }
        }else{
            return 108;
        }
    },

    isFriend: function () {
        var g_id = RoomMgr.Instance().gameId==cc.dd.Define.GameType.CDMJ_FRIEND;
        var c_name = cc.dd.SceneManager.getCurrScene().name==cc.dd.Define.GameId[cc.dd.Define.GameType.CDMJ_FRIEND];
        return g_id && c_name;
    },

    isReplay: function () {
        var g_id = RoomMgr.Instance().gameId==cc.dd.Define.GameType.CDMJ_FRIEND;
        var c_name = cc.dd.SceneManager.getCurrScene().name=='cdmj_replay_game';
        return g_id && c_name;
    },

    isJBC: function () {
        var g_id = RoomMgr.Instance().gameId==cc.dd.Define.GameType.CDMJ_GOLD;
        var c_name = cc.dd.SceneManager.getCurrScene().name==cc.dd.Define.GameId[cc.dd.Define.GameType.CDMJ_GOLD];
        return g_id && c_name;
    },

    isMatch: function () {
        var g_id = RoomMgr.Instance().gameId==cc.dd.Define.GameType.CDMJ_MATCH;
        var c_name = cc.dd.SceneManager.getCurrScene().name==cc.dd.Define.GameId[cc.dd.Define.GameType.CDMJ_MATCH];
        return g_id && c_name;
    },

    isInMaJiang: function () {
        let scenename = cc.dd.SceneManager.getCurrScene().name;
        if(scenename == cc.dd.Define.GameId[cc.dd.Define.GameType.CDMJ_GOLD] || scenename == cc.dd.Define.GameId[cc.dd.Define.GameType.CDMJ_FRIEND] || scenename == 'cdmj_replay_game' || cc.dd.Define.GameId[cc.dd.Define.GameType.CDMJ_MATCH]){
            return true
        }else{
            return false;
        }
    },

    getHuList(){
        var huInfoList = [];    //索引越大,优先级越大
        huInfoList.push({type:HuType.PING_HU,        ani:['hu','huXS'],      audio:'dianpao_hu.mp3'});           //平胡
        huInfoList.push({type:HuType.QING_MO,        ani:['yitiaolong'],    audio:'zimo.mp3'});                 //一条龙
        huInfoList.push({type:HuType.QING_YI_SE,     ani:['qingyise'],     audio:'dianpao_hu.mp3'});     //清一色
        huInfoList.push({type:HuType.QI_DUI,         ani:['hu','huXS'],     audio:'dianpao_hu.mp3'});         //七对
        huInfoList.push({type:HuType.ZHONG_ZHANG,    ani:['hu','huXS'],      audio:'dianpao_hu.mp3'});        //
        huInfoList.push({type:HuType.HUN_YI_SE,      ani:['hu','huXS'],    audio:'dianpao_hu.mp3'});               //夹心五
        huInfoList.push({type:HuType.DI_HU,          ani:['ditu'],      audio:'dianpao_hu.mp3'});        //
        huInfoList.push({type:HuType.HAIDI_LAO,      ani:['hu','huXS'],      audio:'dianpao_hu.mp3'});        //
        huInfoList.push({type:HuType.HAIDI_PAO,      ani:['hu','huXS'],      audio:'dianpao_hu.mp3'});        //
        huInfoList.push({type:HuType.QIANG_HU,      ani:['qiangganghu','qiangganghuXS'],      audio:'dianpao_hu.mp3'});        //
        huInfoList.push({type:HuType.ZI_MO,          ani:['zimo','zimoXS'],    audio:'zimo.mp3'});          //自摸
        huInfoList.push({type:HuType.TIAN_HU,        ani:['tianhu'],    audio:'zimo.mp3'});
        return huInfoList;
    },

    getZimoList(){
        var zimoHuList = [];
        zimoHuList.push({type:HuType.ZI_MO,      ani:['zimo','zimoXS'],    audio:'zimo.mp3'});          //自摸
        zimoHuList.push({type:HuType.QING_MO,     ani:['yitiaolong'],    audio:'zimo.mp3'});                 //一条龙
        zimoHuList.push({type:HuType.QING_YI_SE, ani:['qingyise'],     audio:'zimo.mp3'});     //清一色
        zimoHuList.push({type:HuType.QI_DUI,     ani:['zimo','zimoXS'],     audio:'zimo.mp3'});
        zimoHuList.push({type:HuType.ZHONG_ZHANG, ani:['zimo','zimoXS'],      audio:'zimo.mp3'});        //
        zimoHuList.push({type:HuType.HUN_YI_SE,   ani:['zimo','zimoXS'],    audio:'zimo.mp3'});               //夹心五
        zimoHuList.push({type:HuType.DI_HU,     ani:['ditu'],      audio:'zimo.mp3'});        //
        zimoHuList.push({type:HuType.HAIDI_LAO, ani:['zimo'],      audio:'zimo.mp3'});        //
        zimoHuList.push({type:HuType.HAIDI_PAO, ani:['zimo'],      audio:'zimo.mp3'});        //
        zimoHuList.push({type:HuType.TIAN_HU,   ani:['tianhu'],    audio:'zimo.mp3'});          //自摸
        return zimoHuList;
    },

    initMJComponet(){
        return require("newMjComponentValue").cdmj;
    }
});

module.exports = {
    DeskEvent: base_mj_desk_data.DeskEvent,
    DeskED: base_mj_desk_data.DeskED,
    DeskData: CDMJDeskData,
};