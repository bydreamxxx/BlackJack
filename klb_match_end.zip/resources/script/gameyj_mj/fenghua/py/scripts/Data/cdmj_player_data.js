var RoomMgr = require('jlmj_room_mgr').RoomMgr;
var pai3d_value = require("jlmj_pai3d_value");
var base_mj_player_data = require('new_mj_player_data');

var sc_PlayerData = cc.Class({
    extends: base_mj_player_data.PlayerData,

    /**
     * 初始化游戏数据
     */
    initGameData: function () {
        this._super();
        this.huList = [];
        this.huorder = 0;
    },

    clearCtrlStatus(){
        this.canpeng=false;//能否碰
        this.cangang=false;//能否杠
        this.canbugang=false;//能否补杠
        this.canhu=false;//能否胡
    },

    /**
     * 设置玩家游戏数据
     */
    setGameData: function (playerMsg) {
        this._super(playerMsg);

        this.isMoveHuanPai = false;
        this.dingQue = this.translateDingQue(playerMsg.lackColor);
        // this.huList = playerMsg.playercard.hucardList || [];
        // this.huorder = playerMsg.huorder;
        // this.huTypeList = playerMsg.playercard.hucardtypeList.length > 0 ? playerMsg.playercard.hucardtypeList[playerMsg.playercard.hucardtypeList.length - 1].hucardtypeList : [];
        if(this.isBaoTing){
            this.state = this.require_PlayerState.TINGPAI;
        }else if(this.huList.length > 0){
            this.state = this.require_PlayerState.DAPAI;
            if(!RoomMgr.Instance()._Rule.isxueliu){
                this.state = this.require_PlayerState.SC_HUPAI;

                // if(this.huTypeList.indexOf(3) != -1){//排除自摸的牌
                //     playerMsg.playercard.handcardcount--;
                // }

            }else{
                this.state = this.require_PlayerState.TINGPAI;
                if(this.userId == cc.dd.user.id){
                    this.isBaoTing = true;
                }
            }
        }else{
            this.state = this.require_PlayerState.DAPAI;
        }

        if(playerMsg.handCardsList.length !== 0){
            this.dingQueList = [];
            for(let i = 0; i < this.shoupai.length; i++){
                if(this.getPaiType(this.shoupai[i]) == this.dingQue){
                    this.dingQueList.push(this.shoupai[i]);
                }
            }
        }
    },

    /**
     * 玩家 设置 吃碰杠听胡
     * @param msg
     */
    setCtrlStatus: function (msg, isGangTing) {
        this.canpeng = msg.canpeng;
        this.cangang = msg.cangang;
        this.canbugang = msg.canbugang;
        this.canhu = msg.canhu;
        this.cangangmopai = msg.cangangmopai;

        var caozuoDes = function (canpeng,cangang,canbugang,canhu) {
            var des = "[";
            if(canpeng) { des+=" 碰 " };
            if(cangang) { des+=" 杠 " };
            if(canbugang) { des+=" 补杠 " };
            if(canhu)   { des+=" 胡 " };
            des += "]";
            return des;
        };
        cc.log("【数据】"+"玩家:"+this.userId+" 座位号:"+this.idx+" 操作菜单:"+caozuoDes(this.canpeng,this.cangang,this.canbugang,this.canhu));

        if(this._isUserPlayer){
            var DeskData = require(this.mjComponentValue.deskData).DeskData;
            if(msg.actcard){
                DeskData.Instance().last_chupai_id = msg.actcard.id;
            }
        }
    },

    setCPGTFunc(msg){
        // this.setChiOptions(msg);
        this.setGangOptions(msg);
        if(this._isUserPlayer) {
            // this.setDapaiTing(msg);
        }
        // 菜单显示 延迟到摸牌后
        // PlayerED.notifyEvent(PlayerEvent.CAOZUO,[this, isGangTing]);
    },

    /**
     * 摸牌
     */
    mopai: function (msg) {
        this._super(msg);
        if(this._isUserPlayer){
            if(this.getPaiType(msg) == this.dingQue && this.dingQueList.indexOf(msg) == -1){
                this.dingQueList.push(msg);
            }
        }
    },


    /**
     * 是否有摸牌
     */
    hasMoPai: function () {
        if(this.shoupai.length == 11) {
            if(this.baipai_data_list.length == 1 && this.baipai_data_list[0].cardIds.length == 2){
                return false;
            }else{
                return this.shoupai.length % 3 == 2;
            }
        }if(this.shoupai.length == 12) {
            if(this.baipai_data_list.length == 1 && this.baipai_data_list[0].cardIds.length == 2){
                return true;
            }else{
                return this.shoupai.length % 3 == 2;
            }
        }else{
            return this.shoupai.length % 3 == 2;
        }
    },

    /**
     * 胡
     */
    hu: function(huCardId, huTypeList, isZiMo, huorder) {
        // if(huTypeList == null){
        //     cc.error("【数据】"+"胡牌类型为空");
        //     return;
        // }
        if(!RoomMgr.Instance()._Rule.isxueliu){
            this.state = this.require_PlayerState.SC_HUPAI;
        }else{
            this.state = this.require_PlayerState.TINGPAI;
            if(this.userId == cc.dd.user.id){
                this.isBaoTing = true;
            }
        }
        this.huCardId = huCardId;
        this.huTypeList = huTypeList;
        this.isZiMo = isZiMo;
        this.huorder = huorder;
        this.require_PlayerED.notifyEvent(this.require_PlayerEvent.HU,[this]);
    },

    /**
     * 更新金币
     * @param coin
     */
    changeCoin(coin){
        let oldCoin = this.coin;
        this.coin = oldCoin+coin;
        var DeskData = require('cdmj_desk_data').DeskData;
        if(!DeskData.Instance().isFriend()){
            if(this.coin <= 0){
                coin = -oldCoin;
                this.coin = 0;
                this.state = this.require_PlayerState.PO_CHAN;
            }
        }

        this.require_PlayerED.notifyEvent(this.require_PlayerEvent.CHANGE_COIN,[this, coin]);
    },

    /**
     * 设置金币
     */
    setCoin:function (coin) {
        this.coin = coin;
        var DeskData = require('cdmj_desk_data').DeskData;
        if(!DeskData.Instance().isFriend()){
            if(this.coin <= 0){
                this.state = this.require_PlayerState.PO_CHAN;
            }
        }
        this.require_PlayerED.notifyEvent(this.require_PlayerEvent.SET_COIN,[this]);
    },

    clear(){
        this.huList = [];
        this.dingQue = -1;
        this.dingQueList = [];
        this.isMoveHuanPai = false;
        this.setTips(false);
        this.huan3Zhang_default_option = null;
        this.huan3Zhang_option = null;
        this.huorder = 0;

        this._super();
    },

    clearPai(){
        this.huList = [];
        this.dingQue = -1;
        this.dingQueList = [];
        this.isMoveHuanPai = false;
        this.setTips(false);
        this.huan3Zhang_default_option = null;
        this.huan3Zhang_option = null;
        this.huorder = 0;

        this._super();
    },

    /**
     * 排序手牌
     */
    paixu:function () {
        var getType = function (id) {
            if(id>=72&&id<=107){
                return 2;   //万
            }else if(id>=36&&id<=71){
                return 1;   //条
            }else if(id>=0&&id<=35){
                return 0;   //饼
            }
        };

        let dingqueType = 4 - this.dingQue;

        if(this.hasMoPai()){//有摸牌
            var arr = this.shoupai.splice(0, this.shoupai.length-1);
            arr.sort(function (a, b) {
                var type_a = getType(a);
                var type_b = getType(b);
                if(type_a == dingqueType && type_b != dingqueType){
                    return 1;
                }else if(type_a != dingqueType && type_b == dingqueType ){
                    return -1;
                }else{
                    if(type_a == type_b){
                        return a-b;
                    }else{
                        return type_b - type_a;
                    }
                }
            }.bind(this));
            this.shoupai = arr.concat(this.shoupai);
        }else {
            this.shoupai.sort(function (a, b) {
                var type_a = getType(a);
                var type_b = getType(b);
                if(type_a == dingqueType && type_b != dingqueType){
                    return 1;
                }else if(type_a != dingqueType && type_b == dingqueType ){
                    return -1;
                }else{
                    if(type_a == type_b){
                        return a-b;
                    }else{
                        return type_b - type_a;
                    }
                }
            }.bind(this))
        }
    },

    /**
     * 打牌
     */
    dapai: function (id) {
        // if(this.chupai.indexOf(id) != -1){
        //     return;
        // }

        this._super(id);

        if(this._isUserPlayer) {
            let idx = this.dingQueList.indexOf(id);
            if (idx != -1) {
                this.dingQueList.splice(idx, 1);
            }
        }
    },

    /**
     * 用户玩家 是否有操作选项
     */
    hasCaozuo: function () {
        cc.log('----判断关闭吃碰杠菜单开始---'+this.canpeng+"  "+this.cangang+"  "+this.canhu);
        return this.canpeng||this.cangang||this.canhu;
    },

    ///////////////////////////////////////////////////////////////////////
    /////////////////////////////////新功能/////////////////////////////////
    ///////////////////////////////////////////////////////////////////////
    /**
     * 设置推荐换三张的牌
     * @param value
     */
    setDefaultHuan3Zhang(value){
        this.huan3Zhang_default_option = value;
    },
    /**
     * 设置玩家换三张的牌
     * @param value
     */
    setHuan3Zhang(value){
        this.huan3Zhang_option = value;
    },
    /**
     * 检查换三张条件
     * @returns {boolean}
     */
    checkHuan3Zhang(){
        let huanpaiConut = RoomMgr.Instance()._Rule.huan4zhang ? 4 : 3;

        if(this.huan3Zhang_option && cc.dd._.isArray(this.huan3Zhang_option) && this.huan3Zhang_option.length == huanpaiConut){
            let _result = true;
            let _type = this.huan3Zhang_option[0].type;
            this.huan3Zhang_option.forEach((pai)=>{
                if(pai.type != _type){
                    _result = false;
                }
            })
            return _result;
        }else{
            return false;
        }
    },
    /**
     * 获取牌型
     * @param id
     * @returns {number}
     */
    getPaiType(id){
        if(id <= 35){
            return 2;
        }else if(id <= 71){
            return 1;
        }else {
            return 0;
        }
    },
    /**
     * 响应换三张
     * @param choosePais
     * @param huanPais
     */
    huanPai(choosePais, huanPais){
        this.isMoveHuanPai = false;
        this.setTips(false);
        this.huan3Zhang_default_option = null;
        this.huan3Zhang_option = null;
        // for(let i = 0; i < choosePais.length && i < huanPais.length; i++){
        //     let idx = this.shoupai.indexOf(choosePais[i].id);
        //     if(!cc.dd._.isNull(this.shoupai[idx])){
        //         this.shoupai[idx] = huanPais[i].id;
        //     }
        // }
        for(let i = 0; i < huanPais.length; i++){
            this.shoupai.push(huanPais[i].id);
        }
        this.paixu();
        cc.log("【数据】" + "玩家:" + this.userId + " 座位号:" + this.idx + " 换牌后" + pai3d_value.descs(this.shoupai));
        this.require_PlayerED.notifyEvent(this.require_PlayerEvent.HUAN3ZHANG,[this, choosePais, huanPais]);
    },
    /**
     * 响应换三张出牌
     */
    moveHuanPai(choosepaisList){
        let huanpai = this.checkHuan3Zhang() ? this.huan3Zhang_option : this.huan3Zhang_default_option;
        let huanpaiConut = RoomMgr.Instance()._Rule.huan4zhang ? 4 : 3;

        if(cc.dd._.isArray(choosepaisList)){
            if(this.userId == cc.dd.user.id){

                let same = 0;

                if(cc.dd._.isArray(huanpai)){
                    for(let i = 0; i < choosepaisList.length; i++){
                        for(let j = 0; j < huanpai.length; j++){
                            if(choosepaisList[i].id == huanpai[j].id){
                                same++;
                                break;
                            }
                        }
                    }
                }

                if(same != huanpaiConut){
                    if(this.isMoveHuanPai != true){
                        huanpai = choosepaisList;
                    }else{
                        for(let i = 0; i < huanpai.length; i++){
                            if(this.shoupai.indexOf(huanpai[i].id) == -1){
                                this.shoupai.push(huanpai[i].id);
                            }
                        }

                        for(let i = 0; i < choosepaisList.length; i++){
                            let idx = this.shoupai.indexOf(choosepaisList[i].id)
                            if(idx != -1){
                                this.shoupai.splice(idx, 1);
                            }
                        }
                    }
                    this.huan3Zhang_option = choosepaisList;
                }
            }
        }
        if(this.isMoveHuanPai != true){
            this.isMoveHuanPai = true;

            if(this.userId == cc.dd.user.id){
                cc.log("【数据】" + "玩家:" + this.userId + " 换牌前手牌:" + pai3d_value.descs(this.shoupai));

                for(let i = 0; i < huanpai.length; i++){
                    cc.log("【数据】" + "玩家:" + this.userId + " 换牌id:" + huanpai[i].id);

                    let idx = this.shoupai.indexOf(huanpai[i].id)
                    if(idx != -1){
                        this.shoupai.splice(idx, 1);
                    }
                }
                cc.log("【数据】" + "玩家:" + this.userId + " 换牌手牌:" + pai3d_value.descs(this.shoupai));
            }else{
                this.shoupai.splice(0, huanpaiConut);
            }


            this.require_PlayerED.notifyEvent(this.require_PlayerEvent.MOVE3ZHANG, [this, huanpai]);
        }
    },
    /**
     * 回放的时候快速换三张
     * @param choosepaisList
     * @param huanpaisList
     */
    quickHuan3Zhang(choosepaisList, huanpaisList){
        for(let i = 0; i < choosepaisList.length; i++){
            let idx = this.shoupai.indexOf(choosepaisList[i].id)
            if(idx != -1){
                this.shoupai.splice(idx, 1);
            }
        }
        let temp = [];
        for(let i = 0; i < huanpaisList.length; i++){
            temp.push(huanpaisList[i].id);
        }
        this.addShouPai(temp);
        this.require_PlayerED.notifyEvent(this.require_PlayerEvent.QUICKHUAN3ZHANG, [this, choosepaisList, huanpaisList]);
    },
    /**
     * 设置定缺类型
     * @param type
     */
    setDingQue(type){
        this.isMoveHuanPai = false;
        this.dingQue = this.translateDingQue(type);
        this.dingQueList = [];
        for(let i = 0; i < this.shoupai.length; i++){
            if(this.getPaiType(this.shoupai[i]) == this.dingQue){
                this.dingQueList.push(this.shoupai[i]);
            }
        }
        this.setTips(false);
        this.require_PlayerED.notifyEvent(this.require_PlayerEvent.DING_QUE, [this, this.dingQue]);
    },
    /**
     * 设置提示
     * @param value
     */
    setTips(value){
        cc.log("【数据】玩家:" + this.userId + " 座位号:" + this.idx + " 提示: "+value);
        this.require_PlayerED.notifyEvent(this.require_PlayerEvent.PLAYER_TIPS, [this, value]);
    },

    checkHuaZhu(huazhu){
        // let winIndex = huazhu.winuseridList.indexOf(this.userId);
        // let loseIndex = huazhu.huazhuuseridList.indexOf(this.userId);
        // if(winIndex == -1 && loseIndex == -1){
        //     cc.error("花猪数据有误 ",this.userId);
        //     return;
        // }
        //
        // let index = winIndex == -1 ? loseIndex : winIndex;
        // if(index >= huazhu.huazhufenList.length){
        //     cc.error("花猪分有误 ",this.userId);
        //     return;
        // }
        //
        // let coin = huazhu.huazhufenList[index];
        // if(winIndex == -1){
        //     coin = -coin;
        // }

        cc.log("【数据】花猪 ", this.userId, " 得分 ", huazhu.huazhufen);
        this.require_PlayerED.notifyEvent(this.require_PlayerEvent.HUAZHU,[this, huazhu.ishuazhu]);
        // setTimeout(()=>{
        //     let changeCoin = huazhu.huazhufen;
        //     this.changeCoin(changeCoin);
        // }, 1000);
    },

    checkJiao(jiaoList){
        // let isWin = false;
        // let jaofen = 0;
        //
        // for(let i = 0; i < jiaoList.length; i++){
        //     if(jiaoList[i].winuserid == this.userId){
        //         isWin = true;
        //
        //         for(let j = 0; j < jiaoList[i].chajiaofenList.length; j++){
        //             jaofen += jiaoList[i].chajiaofenList[j];
        //         }
        //     }else{
        //         let index = jiaoList[i].chajiaouseridList.indexOf(this.userId);
        //         if(index >= jiaoList[i].chajiaouseridList.length){
        //             cc.error("查叫分有误 ",this.userId);
        //             return;
        //         }
        //         jaofen += jiaoList[i].chajiaofenList[index];
        //     }
        // }
        //
        // if(!isWin){
        //     jaofen = -jaofen;
        // }

        cc.log("【数据】查叫 ", this.userId, " 得分 ", jiaoList.chajiaofen);
        this.require_PlayerED.notifyEvent(this.require_PlayerEvent.WUJIAO,[this, jiaoList.iswujiao]);
        // setTimeout(()=>{
        //     let changeCoin = jiaoList.chajiaofen;
        //     this.changeCoin(changeCoin);
        // }, 1000);
    },


    translateDingQue(dingque){
        switch(dingque){
            case 0:
                return 0;
            case 16:
                return 1;
            case 32:
                return 2;
            default:
                return dingque;
        }
    },

    initMJComponet(){
        return require("newMjComponentValue").cdmj;
    }
});


module.exports = {
    PlayerEvent:base_mj_player_data.PlayerEvent,
    PlayerED:base_mj_player_data.PlayerED,
    PlayerData:sc_PlayerData,
    PlayerState:base_mj_player_data.PlayerState,
};