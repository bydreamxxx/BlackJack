var jlmj_player_mgr = require('new_mj_player_mgr');
var RoomMgr = require('jlmj_room_mgr').RoomMgr;

var PlayerMgr = cc.Class({
    s_playerMgr: null,
    extends:jlmj_player_mgr,
    statics: {
        Instance: function () {
            if(!this.s_playerMgr){
                this.s_playerMgr = new PlayerMgr();
            }
            return this.s_playerMgr;
        },
        Destroy: function () {
            if(this.s_playerMgr){
                this.s_playerMgr.clear();
                this.s_playerMgr = null;
            }
        },
    },

    ctor: function () {
        this.playing_special_hu = 0;//特殊胡牌动画
    },

    /**
     * 清理玩家数据
     */
    clear: function () {
        this._super();
        this.playing_special_hu = 0;
    },

    checkHuaZhuAndWuJiao(checkList, huazhuWin){

        let huazhuInfo = {};
        let chajiaoInfo = {};
        for(let i = 0; i < this.playerList.length; i++){
            if(this.playerList[i]){
                huazhuInfo[this.playerList[i].userId] = {
                    huazhufen: 0,
                    ishuazhu: false,
                };
                chajiaoInfo[this.playerList[i].userId] = {
                    chajiaofen: 0,
                    iswujiao: false,
                };
            }
        }

        for(let i = 0; i < checkList.length; i++){
            let item = checkList[i];

            if(!cc.dd._.isNull(item.huazhuinfo)){
                let winList = item.huazhuinfo.winuserid;
                if(huazhuInfo[winList]){
                    for(let j = 0; j < item.huazhuinfo.huazhufenList.length; j++){
                        huazhuInfo[winList].huazhufen += (item.huazhuinfo.huazhufenList[j] / huazhuWin);
                    }
                }

                let huazhuList = item.huazhuinfo.huazhuuseridList;
                for(let j = 0; j < huazhuList.length; j++){
                    let winInfo = huazhuList[j];
                    if(huazhuInfo[winInfo]){
                        huazhuInfo[winInfo].huazhufen -= (item.huazhuinfo.huazhufenList[j] / huazhuWin);
                        huazhuInfo[winInfo].ishuazhu = true;
                    }
                }
            }

            for(let j = 0; j < item.chajiaoinfoList.length; j++){
                let jiaoInfo = item.chajiaoinfoList[j];
                if(chajiaoInfo[jiaoInfo.winuserid]){
                    for(let k = 0; k < jiaoInfo.chajiaofenList.length; k++){
                        chajiaoInfo[jiaoInfo.winuserid].chajiaofen += jiaoInfo.chajiaofenList[k];
                    }
                }

                for(let k = 0; k < jiaoInfo.chajiaouseridList.length; k++){
                    let _chajiaoInfo = jiaoInfo.chajiaouseridList[k];
                    if(chajiaoInfo[_chajiaoInfo]){
                        chajiaoInfo[_chajiaoInfo].chajiaofen -= jiaoInfo.chajiaofenList[k];
                        chajiaoInfo[_chajiaoInfo].iswujiao = true;
                    }
                }
            }
        }

        for(let k in huazhuInfo){
            if(huazhuInfo.hasOwnProperty(k)){
                let player = this.getPlayer(Number(k));
                if(player){
                    player.checkHuaZhu(huazhuInfo[k]);
                }
            }
        }

        for(let k in chajiaoInfo){
            if(chajiaoInfo.hasOwnProperty(k)){
                let player = this.getPlayer(Number(k));
                if(player){
                    player.checkJiao(chajiaoInfo[k]);
                }
            }
        }
    },

    getDefaultFriendScore(){
        return 0;
    },

    isFriend(){
        return RoomMgr.Instance().gameId == cc.dd.Define.GameType.CDMJ_FRIEND;
    },

    initMJComponet(){
        return require("newMjComponentValue").cdmj;
    }
});

module.exports = PlayerMgr;
