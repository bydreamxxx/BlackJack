var base_mj_desk_data = require("base_mj_desk_data");

var RoomMgr = require('jlmj_room_mgr').RoomMgr;
var HuType = require('jlmj_define').HuType;
var pai3d_value = require("jlmj_pai3d_value");

var FHMJDeskData = cc.Class({
    extends: base_mj_desk_data.DeskData,

    properties: {

    },

    statics: {

        Instance: function () {
            if (!this.s_desk) {
                this.s_desk = new FHMJDeskData();
            }
            return this.s_desk;
        },

        Destroy: function () {
            if (this.s_desk) {
                this.s_desk.clear();
                this.s_desk = null;
            }
        },

    },

    /**
     * 是否还有剩余牌
     * @returns {boolean}
     */
    hasRemainPai: function () {
        return this.remainCards > this.require_playerMgr.Instance().playerList.length;
    },
    getMJRemainCard(){
        // 还剩几张麻将牌
        return 144;
    },

    isFriend: function () {
        var g_id = RoomMgr.Instance().gameId==cc.dd.Define.GameType.FHMJ_FRIEND;
        var c_name = cc.dd.SceneManager.getCurrScene().name==cc.dd.Define.GameId[cc.dd.Define.GameType.FHMJ_FRIEND];
        return g_id && c_name;
    },

    isReplay: function () {
        var g_id = RoomMgr.Instance().gameId==cc.dd.Define.GameType.FHMJ_FRIEND;
        var c_name = cc.dd.SceneManager.getCurrScene().name=='fhmj_replay_game';
        return g_id && c_name;
    },

    isJBC: function () {
        var g_id = RoomMgr.Instance().gameId==cc.dd.Define.GameType.FHMJ_GOLD;
        var c_name = cc.dd.SceneManager.getCurrScene().name==cc.dd.Define.GameId[cc.dd.Define.GameType.FHMJ_GOLD];
        return g_id && c_name;
    },

    isMatch: function () {
        var g_id = RoomMgr.Instance().gameId==cc.dd.Define.GameType.FHMJ_MATCH;
        var c_name = cc.dd.SceneManager.getCurrScene().name==cc.dd.Define.GameId[cc.dd.Define.GameType.FHMJ_MATCH];
        return g_id && c_name;
    },

    isPassMatch(){
        var g_id = RoomMgr.Instance().gameId==cc.dd.Define.GameType.FHMJ_MATCH_PASS;
        var c_name = cc.dd.SceneManager.getCurrScene().name==cc.dd.Define.GameId[cc.dd.Define.GameType.FHMJ_MATCH_PASS];
        return g_id && c_name;
    },
    isInMaJiang: function () {
        let scenename = cc.dd.SceneManager.getCurrScene().name;
        if(scenename == cc.dd.Define.GameId[cc.dd.Define.GameType.FHMJ_GOLD] || scenename == cc.dd.Define.GameId[cc.dd.Define.GameType.FHMJ_FRIEND] || scenename =='fhmj_replay_game' || cc.dd.Define.GameId[cc.dd.Define.GameType.FHMJ_MATCH] || cc.dd.Define.GameId[cc.dd.Define.GameType.FHMJ_MATCH_PASS]){
            return true
        }else{
            return false;
        }
    },

    getHuList(){
        var huInfoList = [];    //索引越大,优先级越大
        huInfoList.push({type:HuType.PING_HU, ani:['hu'], audio:'hu.mp3'});
        huInfoList.push({type:HuType.QIANG_HU, ani:['hu'], audio:'hu.mp3'});
        huInfoList.push({type:HuType.XIAO_SA, ani:['hu'], audio:'hu.mp3'});
        huInfoList.push({type:HuType.GANG_PAO_HU, ani:['hu'], audio:'hu.mp3'});
        huInfoList.push({type:HuType.DANDIAO_PIAOHU, ani:['hu'], audio:'hu.mp3'});
        huInfoList.push({type:HuType.ZHIZUN_HAO_QI, ani:['animation'], audio:'hu.mp3'});
        huInfoList.push({type:HuType.PIAO_HU, ani:['ddc'], audio:'hu.mp3'});
        huInfoList.push({type:HuType.ZHUANG_HU, ani:['ddd'], audio:'hu.mp3'});
        huInfoList.push({type:HuType.SHUANG_HAO_QI, ani:['hys'], audio:'hu.mp3'});
        huInfoList.push({type:HuType.QING_YI_SE, ani:['wgh'], audio:'hu.mp3'});
        huInfoList.push({type:HuType.LI_HU, ani:['qdt'], audio:'hu.mp3'});
        huInfoList.push({type:HuType.QI_DUI, ani:['ddh'], audio:'hu.mp3'});
        huInfoList.push({type:HuType.HAO_QI, ani:['qys'], audio:'hu.mp3'});
        huInfoList.push({type:HuType.GANG_HUA_HU, ani:['hu'], audio:'hu.mp3'});
        huInfoList.push({type:HuType.TIAN_HU, ani:['hu'], audio:'hu.mp3'});
        huInfoList.push({type:HuType.JIA_HU, ani:['sbd'], audio:'hu.mp3'});
        huInfoList.push({type:HuType.DUI_BAO, ani:['llt'], audio:'hu.mp3'});
        huInfoList.push({type:HuType.SHOU_BA_YI, ani:['bahua'], audio:'hu.mp3'});
        huInfoList.push({type:HuType.MO_BAO, ani:['qlt'], audio:'hu.mp3'});
        huInfoList.push({type:HuType.BIAN_HU, ani:['hu'], audio:'hu.mp3'});

        huInfoList.push({type:HuType.ZI_MO, ani:['zimo'], audio:'hu.mp3'});          //自摸
        return huInfoList;
    },

    getZimoList(){
        var zimoHuList = [];
        zimoHuList.push({type:HuType.ZI_MO, ani:['zimo'], audio:'hu.mp3'});
        zimoHuList.push({type:HuType.QIANG_HU, ani:['zimo'], audio:'hu.mp3'});
        zimoHuList.push({type:HuType.XIAO_SA, ani:['zimo'], audio:'hu.mp3'});
        zimoHuList.push({type:HuType.GANG_PAO_HU, ani:['zimo'], audio:'hu.mp3'});
        zimoHuList.push({type:HuType.DANDIAO_PIAOHU, ani:['zimo'], audio:'hu.mp3'});
        zimoHuList.push({type:HuType.ZHIZUN_HAO_QI, ani:['animation'], audio:'hu.mp3'});
        zimoHuList.push({type:HuType.PIAO_HU, ani:['ddc'], audio:'hu.mp3'});
        zimoHuList.push({type:HuType.ZHUANG_HU, ani:['ddd'], audio:'hu.mp3'});
        zimoHuList.push({type:HuType.SHUANG_HAO_QI, ani:['hys'], audio:'hu.mp3'});
        zimoHuList.push({type:HuType.QING_YI_SE, ani:['wgh'], audio:'hu.mp3'});
        zimoHuList.push({type:HuType.LI_HU, ani:['qdt'], audio:'hu.mp3'});
        zimoHuList.push({type:HuType.QI_DUI, ani:['ddh'], audio:'hu.mp3'});
        zimoHuList.push({type:HuType.HAO_QI, ani:['qys'], audio:'hu.mp3'});
        zimoHuList.push({type:HuType.GANG_HUA_HU, ani:['zimo'], audio:'hu.mp3'});
        zimoHuList.push({type:HuType.TIAN_HU, ani:['zimo'], audio:'hu.mp3'});
        zimoHuList.push({type:HuType.JIA_HU, ani:['sbd'], audio:'hu.mp3'});
        zimoHuList.push({type:HuType.DUI_BAO, ani:['llt'], audio:'hu.mp3'});
        zimoHuList.push({type:HuType.SHOU_BA_YI, ani:['bahua'], audio:'hu.mp3'});
        zimoHuList.push({type:HuType.MO_BAO, ani:['qlt'], audio:'hu.mp3'});
        zimoHuList.push({type:HuType.BIAN_HU, ani:['zimo'], audio:'hu.mp3'});
        return zimoHuList;
    },

    getHuAnimInfo:function (huType, isZimo) {
        switch (huType){
            case HuType.SHOU_BA_YI:
                return 'hua_ani';
            case HuType.ZHIZUN_HAO_QI:
                return 'gangshanghua_ani';
            case HuType.PING_HU:
            case HuType.ZI_MO:
            case HuType.QIANG_HU:
            case HuType.XIAO_SA:
            case HuType.GANG_PAO_HU:
            case HuType.DANDIAO_PIAOHU:
            case HuType.GANG_HUA_HU:
            case HuType.TIAN_HU:
            case HuType.BIAN_HU:
                return 'hu_ani';
            case HuType.DUI_BAO:
            case HuType.MO_BAO:
                return 'laotou_ani';
            case HuType.HAO_QI:
            case HuType.SHUANG_HAO_QI:
                return 'yise_ani';
            default:
                return 'duihu_ani';
        }
    },

    isHunPai: function(id){
        if(this.hunPai >= 136 && this.hunPai <= 139){
            return id >= 136 && id <= 139;
        }else if(this.hunPai >= 140){
            return id >= 140;
        }else{
            let des = pai3d_value.desc[id].split('[')[0];
            return des == this.hunPai;
        }

    },

    getMaxTime(){
        return 10;
    },

    /**
     * 设置宝牌
     * @param baoPaiValue 宝牌的值
     */
    setBaoPai: function (baoPaiValue) {
        this.unBaopai = baoPaiValue;
        if(this.unBaopai >= 0){
            if(this.unBaopai >= 136){
                this.hunPai = this.unBaopai;
            }else{
                let des = pai3d_value.desc[this.unBaopai].split('[')[0];
                this.hunPai = this.getHunPaiStr(des[0]);
                if(des.length == 2){
                    this.hunPai += des[1];
                }
            }

        }
        cc.log("亮牌值:", baoPaiValue, "混牌 ", this.hunPai);
        // DeskED.notifyEvent(DeskEvent.UPDATE_BAO_PAI, []);
    },

    getHunPaiID(){
        switch(this.hunPai){
            case '东':
                return 120;
            case '南':
                return 124;
            case '西':
                return 128;
            case '北':
                return 132;
            case '中':
                return 108;
            case '发':
                return 112;
            case '白':
                return 116;
            case '一筒':
                return 0;
            case '二筒':
                return 4;
            case '三筒':
                return 8;
            case '四筒':
                return 12;
            case '五筒':
                return 16;
            case '六筒':
                return 20;
            case '七筒':
                return 24;
            case '八筒':
                return 28;
            case '九筒':
                return 32;
            case '一条':
                return 36;
            case '二条':
                return 40;
            case '三条':
                return 44;
            case '四条':
                return 48;
            case '五条':
                return 52;
            case '六条':
                return 56;
            case '七条':
                return 60;
            case '八条':
                return 64;
            case '九条':
                return 68;
            case '一万':
                return 72;
            case '二万':
                return 76;
            case '三万':
                return 80;
            case '四万':
                return 84;
            case '五万':
                return 88;
            case '六万':
                return 92;
            case '七万':
                return 96;
            case '八万':
                return 100;
            case '九万':
                return 104;
            default:
                return this.hunPai;
        }
    },

    getHunPaiStr(str){
        return str;
    },

    initMJComponet(){
        return require("mjComponentValue").fhmj;
    }
});

module.exports = {
    DeskEvent: base_mj_desk_data.DeskEvent,
    DeskED: base_mj_desk_data.DeskED,
    DeskData: FHMJDeskData,
};