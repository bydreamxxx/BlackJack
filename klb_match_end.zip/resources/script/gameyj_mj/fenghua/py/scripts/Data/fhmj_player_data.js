var base_mj_player_data = require('base_mj_player_data');
var pai3d_value = require("jlmj_pai3d_value");
var BaipaiType = require("jlmj_baipai_data").BaipaiType;
var BaipaiData = require("jlmj_baipai_data").BaipaiData;
var mjComponentValue = null;
var BAIPAI_TYPE = require("Define").ComposeCardType;
var JLGData = require("jlmj_baipai_data").JLGData;

var bc_PlayerData = cc.Class({
    extends: base_mj_player_data.PlayerData,

    ctor: function () {
        mjComponentValue = this.initMJComponet();
    },

    /**
     * 用户玩家 是否有操作选项
     */
    hasCaozuo: function () {
        cc.log('----判断关闭吃碰杠菜单开始---'+this.canchi+"  "+this.canpeng+"  "+this.cangang+"  "+this.cangu+"  "+this.canhu+"  "+this.canbuhua);
        return this.canchi||this.canpeng||this.cangang||this.cangu||this.canhu||this.canbuhua;
    },

    clearCtrlStatus(){
        this.canchi = false;
        this.canpeng = false;
        this.cangang = false;
        this.canbugang = false;
        this.canhu = false;
        this.cangangmopai = false;
        this.cangu = false;
        this.canbuhua = false;
    },

    /**
     * 玩家 设置 吃碰杠听胡
     * @param msg
     */
    setCtrlStatus: function (msg, isGangTing) {
        this.canchi = msg.canchi;
        this.canpeng = msg.canpeng;
        this.cangang = msg.cangang;
        this.canbugang = msg.canbugang;
        this.canhu = msg.canhu;
        this.cangu = msg.cangu;
        this.cangangmopai = msg.cangangmopai;
        this.canbuhua = msg.canbuhua;


        var caozuoDes = function (canchi,canpeng,cangang,canbugang,canhu,cangu,canbuhua) {
            var des = "[";
            if(canchi)  { des+=" 吃 " };
            if(canpeng) { des+=" 碰 " };
            if(cangang) { des+=" 杠 " };
            if(canbugang) { des+=" 补杠 " };
            if(canhu)   { des+=" 胡 " };
            if(cangu)   { des+=" 海底摸牌 " };
            if(canbuhua)   { des+=" 补花 " };
            des += "]";
            return des;
        };
        cc.log("【数据】"+"玩家:"+this.userId+" 座位号:"+this.idx+" 操作菜单:"+caozuoDes(this.canchi,this.canpeng,this.cangang,this.canbugang,this.canhu,this.cangu,this.canbuhua));


        if(this._isUserPlayer){
            var DeskData = require(mjComponentValue.deskData).DeskData;
            if(msg.actcard){
                DeskData.Instance().last_chupai_id = msg.actcard.id;
            }
        }
    },

    setCPGTFunc(msg){
        this.setChiOptions(msg);
        this.setGangOptions(msg);
        if(this._isUserPlayer) {
            this.setDapaiTing(msg);
        }

        // 菜单显示 延迟到摸牌后
        // PlayerED.notifyEvent(PlayerEvent.CAOZUO,[this, isGangTing]);
    },


    /**
     * 是否有摸牌
     */
    hasMoPai: function () {
        if(this.shoupai.length == 11) {
            if(this.baipai_data_list.length == 1 && this.baipai_data_list[0].cardIds.length == 2){
                return false;
            }else{
                return this.shoupai.length % 3 == 2;
            }
        }else if(this.shoupai.length == 12) {
            if(this.baipai_data_list.length == 1 && this.baipai_data_list[0].cardIds.length == 2){
                return true;
            }else{
                return this.shoupai.length % 3 == 2;
            }
        }else{
            return this.shoupai.length % 3 == 2;
        }
    },

    /**
     * 排序手牌
     */
    paixu:function () {
        var getType = function (id) {
            if(id>=72&&id<=107){
                return 6;   //万
            }else if(id>=36&&id<=71){
                return 5;   //条
            }else if(id>=0&&id<=35){
                return 4;   //饼
            }else if(id>=120&&id<=135){
                return 3;   //东南西北
            }else if(id>=108&&id<=119){
                return 2;   //中发白
            }else if(id>=136&&id<=143){
                return 1;   //梅兰竹菊春夏秋冬
            }
        };
        var DeskData = require(mjComponentValue.deskData).DeskData;
        if(DeskData.Instance().unBaopai >= 0){
            if(this.hasMoPai()){//有摸牌
                var arr = this.shoupai.splice(0, this.shoupai.length-1);
                arr.sort(function (a, b) {
                    if(DeskData.Instance().isHunPai(a)){
                        return -1;
                    }else if(DeskData.Instance().isHunPai(b)) {
                        return 1;
                    }else{
                        var type_a = getType(a);
                        var type_b = getType(b);
                        if(type_a == type_b){
                            return a-b;
                        }else{
                            return type_b - type_a;
                        }
                    }
                });
                this.shoupai = arr.concat(this.shoupai);
            }else {
                this.shoupai.sort(function (a, b) {
                    if(DeskData.Instance().isHunPai(a)){
                        return -1;
                    }else if(DeskData.Instance().isHunPai(b)) {
                        return 1;
                    }else{
                        var type_a = getType(a);
                        var type_b = getType(b);
                        if(type_a == type_b){
                            return a-b;
                        }else{
                            return type_b - type_a;
                        }
                    }
                })
            }
        }else{
            if(this.hasMoPai()){//有摸牌
                var arr = this.shoupai.splice(0, this.shoupai.length-1);
                arr.sort(function (a, b) {
                    var type_a = getType(a);
                    var type_b = getType(b);
                    if(type_a == type_b){
                        return a-b;
                    }else{
                        return type_b - type_a;
                    }
                });
                this.shoupai = arr.concat(this.shoupai);
            }else {
                this.shoupai.sort(function (a, b) {
                    var type_a = getType(a);
                    var type_b = getType(b);
                    if(type_a == type_b){
                        return a-b;
                    }else{
                        return type_b - type_a;
                    }
                })
            }
        }

    },

    /**
     * 吃
     */
    chi:function (chicardList, viewIdx) {
        if(!chicardList){
            cc.error("【数据】"+"吃牌列表为空");
            return;
        }

        var chiIds = [];
        chicardList.forEach(function (card) {
            if(card){
                chiIds.push(card.id);
            }else{
                cc.error("【数据】"+"吃牌列表项为空");
            }
        });
        this.delShouPai(chiIds,2);
        cc.log("【数据】"+"玩家:"+this.userId+" 座位号:"+this.idx+" 吃牌:"+pai3d_value.descs(chiIds));

        var baipai_data = new BaipaiData();
        baipai_data.index = this.baipai_data_list.length;
        var mj_index = 0;
        this.baipai_data_list.forEach(function(baipai){
            mj_index += baipai.down_pai_num;
        });
        baipai_data.mj_index = mj_index;
        baipai_data.type = BaipaiType.CHI;
        baipai_data.down_pai_num = 3;
        baipai_data.cardIds = chiIds;
        baipai_data.viewIdx = viewIdx;
        this.baipai_data_list.push(baipai_data);

        cc.log("【数据】"+"玩家:"+this.userId+" 座位号:"+this.idx+" 摆牌:");
        this.baipai_data_list.forEach(function(item){
            cc.log(item.toString());
        });

        this.resetBaiPaiIndex();

        this.require_PlayerED.notifyEvent(this.require_PlayerEvent.CHI,[this,baipai_data]);

    },

    /**
     * 碰
     */
    peng: function (pengcardList, viewIdx) {
        if(!pengcardList){
            cc.error("【数据】"+"碰牌列表为空");
            return;
        }

        var pengIds = [];
        pengcardList.forEach(function (card) {
            if(card){
                pengIds.push(card.id);
            }else{
                cc.error("【数据】"+"碰牌列表项为空");
            }
        });
        this.delShouPai(pengIds,2);
        cc.log("【数据】"+"玩家:"+this.userId+" 座位号:"+this.idx+" 碰牌:"+pai3d_value.descs(pengIds));

        var baipai_data = new BaipaiData();
        baipai_data.index = this.baipai_data_list.length;
        var mj_index = 0;
        this.baipai_data_list.forEach(function(baipai){
            mj_index += baipai.down_pai_num;
        });
        baipai_data.mj_index = mj_index;
        baipai_data.type = BaipaiType.PENG;
        baipai_data.down_pai_num = 3;
        baipai_data.cardIds = pengIds;
        baipai_data.viewIdx = viewIdx;
        this.baipai_data_list.push(baipai_data);

        cc.log("【数据】"+"玩家:"+this.userId+" 座位号:"+this.idx+" 摆牌:");
        this.baipai_data_list.forEach(function(item){
            cc.log(item.toString());
        });

        this.resetBaiPaiIndex();
        this.require_PlayerED.notifyEvent(this.require_PlayerEvent.PENG,[this,baipai_data]);

    },

    /**
     * 杠
     */
    gang: function (msg, viewIdx) {
        switch (msg.gangtype) {
            case 1:
            case 8: //大蛋明杠
            case 10: //2饼明杠
            case 12: //8万明杠
            case 14://幺鸡明杠
            case 16://普通明杠 大杠
                this.diangang(msg.gangcardList, true, viewIdx);    //点杠
                return;
        }

        this._super(msg, viewIdx);
    },

    /**
     * 点杠
     */
    diangang: function (gangcardList, play_audio, viewIdx) {
        if(!gangcardList){
            cc.error("【数据】"+"点杠牌列表为空");
            return;
        }
        let shoupaiGangCount = 0;
        var gangIds = [];
        gangcardList.forEach(function (card) {
            if(card){
                gangIds.push(card.id);
                if(this.getBaipaiDataByid(card.id)){
                    shoupaiGangCount++;
                }
            }else{
                cc.error("【数据】"+"点杠牌列表项为空");
            }
        }.bind(this));

        if(gangIds.length != 4){
            cc.error("【数据】"+"点杠牌数目 != 4");
            return;
        }

        if(shoupaiGangCount >= 3){
            cc.error("【数据】"+"点杠手牌数目不对"+shoupaiGangCount);
            return;
        }

        this.delShouPai(gangIds, 3);
        cc.log("【数据】"+"玩家:"+this.userId, '点杠列表',pai3d_value.descs(gangIds));
        var baipai_data = new BaipaiData();
        baipai_data.type = BaipaiType.DIANGANG;
        baipai_data.down_pai_num = 3;
        baipai_data.cardIds = gangIds;
        baipai_data.viewIdx = viewIdx;
        this.baipai_data_list.push(baipai_data);
        this.resetBaiPaiIndex();
        this.require_PlayerED.notifyEvent(this.require_PlayerEvent.DIANGANG, [this, baipai_data, play_audio]);

    },

    /**
     * 巴杠
     */
    bagang: function (gangcardList, play_audio, viewIdx) {
        if(!gangcardList){
            cc.error("【数据】"+"巴杠牌列表为空");
            return;
        }

        var gangIds = [];
        gangcardList.forEach(function (card) {
            if(card){
                gangIds.push(card.id);
            }else{
                cc.error("【数据】"+"巴杠牌列表项为空");
            }
        });
        //服务器默认 巴杠的牌放在最后一个 即:gangIds[3]
        var baipai_data = this.getPengData(BaipaiType.PENG, gangIds[0]);
        if(!baipai_data){
            cc.error("【数据】"+"玩家摆牌数据，没有该碰牌"+pai3d_value.descs(gangIds));
            return;
        }
        var ids = cc.dd._.without(gangIds,baipai_data.cardIds[0],baipai_data.cardIds[1],baipai_data.cardIds[2]);
        if(ids.length != 1){
            cc.error("【数据】"+"玩家手牌摸牌中无巴杠牌");
            return;
        }
        var bagang_id = ids[0];
        let shoupaiGangCount = 0;
        if(this.getBaipaiDataByid(bagang_id)){
            shoupaiGangCount++;
        }
        if(shoupaiGangCount >= 1){
            cc.error("【数据】"+"巴杠手牌数目不对"+shoupaiGangCount);
            return;
        }
        this.delShouPai([bagang_id], 1);
        cc.log("【数据】"+"玩家:"+this.userId, '巴杠列表',pai3d_value.descs(gangIds));
        baipai_data.cardIds.push(bagang_id);
        baipai_data.down_pai_num = 3;
        baipai_data.type = BaipaiType.BAGANG;
        if(cc.dd._.isNumber(viewIdx)){
            baipai_data.viewIdx = viewIdx;
        }
        this.resetBaiPaiIndex();
        this.require_PlayerED.notifyEvent(this.require_PlayerEvent.BAGANG, [this, baipai_data, play_audio]);
    },

    /**
     * 初始化摆牌数据
     */
    initBaiPaiData: function( baipaiDataList ) {
        if( !baipaiDataList ) {
            return;
        }
        this.baipai_data_list = [];

        var index = 0;
        var mj_index = 0;
        for( var i = 0; i < baipaiDataList.length; ++i ) {
            var baipai_data = baipaiDataList[i];

            if(baipai_data.type == BAIPAI_TYPE.C_BUHUA){
                let list = [];

                baipai_data.cardsList.forEach((card)=>{
                    if(card){
                        list.push(card.id);
                    }
                })

                this.buhua_data = new BaipaiData();
                this.buhua_data.index = this.baipai_data_list.length;

                this.buhua_data.mj_index = 0;
                this.buhua_data.type = BaipaiType.BUHUA;
                this.buhua_data.cardIds = list;
                continue;
            }

            var baipai_object = null;
            if( baipai_data.type == 0 || baipai_data.type == 10) {
                continue;
            }
            if( this.getIsCCG( baipai_data.type ) ) {
                baipai_object = new JLGData();
                var isqc = baipai_data.cardsList.length>3;
                for(var k=0; k<baipai_data.cardsList.length; ++k){
                    this.convertData(baipai_object.idAndCnts, baipai_data.cardsList[k], isqc);
                }
                if(baipai_object.idAndCnts.length<3)
                {
                    var idAndCnt = {};
                    idAndCnt.cnt = 1;
                    var xiaoji = baipai_object.findXJTwoCnt();
                    xiaoji.cnt--;
                    idAndCnt.id = xiaoji.id;
                    baipai_object.idAndCnts.push(idAndCnt);
                    baipai_object.sortArr();
                }
                baipai_object.down_pai_num = baipai_object.getShowPaiList().length;
            } else {
                baipai_object = new BaipaiData();
                baipai_object.down_pai_num = 3; //吃 碰 明杠 暗杠 下层牌数=3
                if(this.userId !== baipai_data.useridout){
                    baipai_object.userIdOut = baipai_data.useridout;
                }
            }
            this.copyObj(baipai_object.cardIds, baipai_data.cardsList );
            baipai_object.index += index;
            baipai_object.mj_index += mj_index;
            baipai_object.type = this.transBaiPaiType( baipai_data.type );
            ++index;
            mj_index += baipai_object.down_pai_num;

            this.baipai_data_list.push( baipai_object );
        }
    },

    /**
     * 设置玩家游戏数据
     */
    setGameData: function (playerMsg) {
        this.hasGameData = true;   //是否有游戏数据
        this.userId = playerMsg.userid;
        this.coin = playerMsg.coin;
        this.nickname = playerMsg.nickname;
        this.name = playerMsg.nickname;
        this.sex = playerMsg.sex;
        this.ip = playerMsg.ip;
        this.address = playerMsg.address;
        this.idx = playerMsg.site;
        this.headUrl = playerMsg.wxinfo.headurl;

        this.isbanker = playerMsg.isbanker;
        this.isOwner = playerMsg.isowner;
        this.bready = playerMsg.bready;
        this.nHuPai = playerMsg.nhupai;
        this.gameStatus = playerMsg.gamestatus;
        this.agentMode = playerMsg.agentmode;
        this.isBaoTing = playerMsg.isbaoting;
        if(this.isBaoTing){
            this.state = base_mj_player_data.PlayerState.TINGPAI;
        }else{
            this.state = base_mj_player_data.PlayerState.DAPAI;
        }

        this.chupai = [];              //出牌
        playerMsg.playercard.outcardList.forEach(function (card) {
            this.chupai.push(card.id)
        }.bind(this));
        this.shoupai = [];             //手牌
        // if(playerMsg.userid != cc.dd.user.id){
        //     for(var i=0; i<playerMsg.playercard.handcardcount; ++i){
        //         this.shoupai.push(0);
        //     }
        // }else {
        //     playerMsg.playercard.handcardList.forEach(function (card) {
        //         this.pushData(this.shoupai,card.id);
        //     }.bind(this));
        //     // this.paixu();
        //     if(playerMsg.playercard.mopai && playerMsg.playercard.mopai.id){
        //         this.pushData(this.shoupai,playerMsg.playercard.mopai.id);
        //     }
        // }

        //回放时,所有玩家的手牌都看得到
        if(playerMsg.playercard.handcardList.length == 0){
            for(var i=0; i<playerMsg.playercard.handcardcount; ++i){
                this.shoupai.push(0);
            }
        }else{
            playerMsg.playercard.handcardList.forEach(function (card) {
                this.pushData(this.shoupai,card.id);
            }.bind(this));
            // this.paixu();
            if(playerMsg.playercard.mopai && playerMsg.playercard.mopai.id >= 0){
                this.pushData(this.shoupai,playerMsg.playercard.mopai.id);
            }
        }
        this.baipai_data_list = [];    //摆牌
        this.buhua_data = null;         //补花信息

        this.initBaiPaiData( playerMsg.playercard.composecardList );
        cc.log("座位号:",this.idx," 手牌数:",this.shoupai.length);
        this.kaipai_an_gang_list = [];
    },

    /**
     * 设置玩家牌数据
     * 朋友场 新一局
     * @param Msg
     */
    setCardList: function (Msg) {
        this.dapaiCD=0;  //打牌cd
        this.clearCtrlStatus();
        this.isZiMo= null;// 是否自摸
        this.state = base_mj_player_data.PlayerState.DAPAI;
        this.nHuPai = 0;// 是否已胡牌
        this.gameStatus = 0;// 玩家游戏状态
        this.agentMode = 0;// 托管状态
        this.isBaoTing = false;// 是否已报听
        this.isTempBaoTing = false;// 客户端处理听牌表现
        this.isTempBaoTing = false;
        this.isTempGang = false;// 客户端听牌 后的杠牌

        this.chupai = [];              //出牌
        this.shoupai = [];             //手牌
        if(Msg.userid != cc.dd.user.id){
            for(let i=0; i<Msg.handcardcount; ++i){
                this.shoupai.push(0);
            }
        }else {
            Msg.handcardList.forEach(function (card) {
                this.pushData(this.shoupai,card.id);
            }.bind(this));
            // this.paixu();
            if(Msg.mopai && cc.dd._.isNumber(Msg.mopai.id)){
                this.pushData(this.shoupai,Msg.mopai.id);
            }
        }
        this.baipai_data_list = [];    //摆牌
        this.buhua_data = null;         //补花信息

        this.initBaiPaiData( Msg.composecardList );
        cc.log("座位号:",this.idx," 手牌数:",this.shoupai.length);
        this.kaipai_an_gang_list = [];
    },

    playBuhua(){
        this.require_PlayerED.notifyEvent(this.require_PlayerEvent.BUHUA,[this, this.buhua_data, true]);
    },

    initMJComponet(){
        return require("mjComponentValue").fhmj;
    }
});


module.exports = {
    PlayerEvent:base_mj_player_data.PlayerEvent,
    PlayerED:base_mj_player_data.PlayerED,
    PlayerData:bc_PlayerData,
    PlayerState:base_mj_player_data.PlayerState,
};