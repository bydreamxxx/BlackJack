
var SdyTextCfg = {

    UNKNOW_ERR:     '服务器未知错误!',

    //叫分错误码
    JIAOFEN_ERR_1:  '当前不该你操作!',
    JIAOFEN_ERR_2:  '不能叫这个分数!',

    //选花色错误
    SELECT_COLOR_ERR_1: '当前不该你操作!',
    SELECT_COLOR_ERR_2: '没有此花色',

    //扣底牌错误
    KOU_ERR_1:     '当前不该你操作!',
    KOU_ERR_2:     '扣底牌数不对!',
    KOU_ERR_3:     '没有此牌!',

    //出牌
    CHUPAI_ERR_1:   '当前不该你操作!',
    CHUPAI_ERR_2:   '没有此牌!',
    CHUPAI_ERR_3:   '出牌错误!',
};

module.exports = SdyTextCfg;