
var SdyAudioCommon = {
    BOMB:               'resources/gameyj_sdy/jbc/audio/bomb.mp3',
    GENPAI:             'resources/gameyj_sdy/jbc/audio/genpai.mp3',
    SEND:               'resources/gameyj_sdy/jbc/audio/send.mp3',
};

var SdyAudioFemale = {
    SCORE_0:             'resources/gameyj_sdy/jbc/audio/0/0.mp3',
    SCORE_60:            'resources/gameyj_sdy/jbc/audio/0/60.mp3',
    SCORE_65:            'resources/gameyj_sdy/jbc/audio/0/65.mp3',
    SCORE_70:            'resources/gameyj_sdy/jbc/audio/0/70.mp3',
    SCORE_75:            'resources/gameyj_sdy/jbc/audio/0/75.mp3',
    ZHU_HEITAO:          'resources/gameyj_sdy/jbc/audio/0/zhu_3.mp3',
    ZHU_HONGTAO:         'resources/gameyj_sdy/jbc/audio/0/zhu_2.mp3',
    ZHU_FANGPIAN:        'resources/gameyj_sdy/jbc/audio/0/zhu_0.mp3',
    ZHU_MEIHUA:          'resources/gameyj_sdy/jbc/audio/0/zhu_1.mp3',
    CARD_2:              'resources/gameyj_sdy/jbc/audio/0/2.mp3',
    DIAOZHU:             'resources/gameyj_sdy/jbc/audio/0/diaozhu.mp3',
    HEITAO:              'resources/gameyj_sdy/jbc/audio/0/heitao.mp3',
    HONGTAO:             'resources/gameyj_sdy/jbc/audio/0/hongtao.mp3',
    FANGPIAN:            'resources/gameyj_sdy/jbc/audio/0/fangpian.mp3',
    MEIHUA:              'resources/gameyj_sdy/jbc/audio/0/meihua.mp3',
    DAWANG:              'resources/gameyj_sdy/jbc/audio/0/king2.mp3',
    XIAOWANG:            'resources/gameyj_sdy/jbc/audio/0/king1.mp3',
    CARD_SCORE_5:        'resources/gameyj_sdy/jbc/audio/0/out5.mp3',
    CARD_SCORE_10:       'resources/gameyj_sdy/jbc/audio/0/out10.mp3',
    GUANSHANG:           'resources/gameyj_sdy/jbc/audio/0/max.mp3',
    ZHU_2:               'resources/gameyj_sdy/jbc/audio/0/zhu2.mp3',
    ZHU_SHA:             'resources/gameyj_sdy/jbc/audio/0/zhusha.mp3',
};

var SdyAudioMale = {
    SCORE_0:             'resources/gameyj_sdy/jbc/audio/1/0.mp3',
    SCORE_60:            'resources/gameyj_sdy/jbc/audio/1/60.mp3',
    SCORE_65:            'resources/gameyj_sdy/jbc/audio/1/65.mp3',
    SCORE_70:            'resources/gameyj_sdy/jbc/audio/1/70.mp3',
    SCORE_75:            'resources/gameyj_sdy/jbc/audio/1/75.mp3',
    ZHU_HEITAO:          'resources/gameyj_sdy/jbc/audio/1/zhu_3.mp3',
    ZHU_HONGTAO:         'resources/gameyj_sdy/jbc/audio/1/zhu_2.mp3',
    ZHU_FANGPIAN:        'resources/gameyj_sdy/jbc/audio/1/zhu_0.mp3',
    ZHU_MEIHUA:          'resources/gameyj_sdy/jbc/audio/1/zhu_1.mp3',
    CARD_2:              'resources/gameyj_sdy/jbc/audio/1/2.mp3',
    DIAOZHU:             'resources/gameyj_sdy/jbc/audio/1/diaozhu.mp3',
    HEITAO:              'resources/gameyj_sdy/jbc/audio/1/heitao.mp3',
    HONGTAO:             'resources/gameyj_sdy/jbc/audio/1/hongtao.mp3',
    FANGPIAN:            'resources/gameyj_sdy/jbc/audio/1/fangpian.mp3',
    MEIHUA:              'resources/gameyj_sdy/jbc/audio/1/meihua.mp3',
    DAWANG:              'resources/gameyj_sdy/jbc/audio/1/king2.mp3',
    XIAOWANG:            'resources/gameyj_sdy/jbc/audio/1/king1.mp3',
    CARD_SCORE_5:        'resources/gameyj_sdy/jbc/audio/1/out5.mp3',
    CARD_SCORE_10:       'resources/gameyj_sdy/jbc/audio/1/out10.mp3',
    GUANSHANG:           'resources/gameyj_sdy/jbc/audio/1/max.mp3',
    ZHU_2:               'resources/gameyj_sdy/jbc/audio/1/zhu2.mp3',
    ZHU_SHA:             'resources/gameyj_sdy/jbc/audio/1/zhusha.mp3',
};

var SdyAudioCfg = [SdyAudioFemale,SdyAudioMale,SdyAudioCommon];

module.exports = SdyAudioCfg;