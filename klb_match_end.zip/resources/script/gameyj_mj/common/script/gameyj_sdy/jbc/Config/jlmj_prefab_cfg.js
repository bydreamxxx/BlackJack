
module.exports = {
    //玩法规则
    JLMJ_RULE: 'gameyj_mj/jilin/py/prefabs/jlmj_rule',
    //分享
    JLMJ_SHARE: 'gameyj_mj/common/prefabs/mj_shardPopBox',
    //第几圈
    JLMJ_TIPS_POP: 'gameyj_mj/common/prefabs/jlmj_tips_pop',
    //个人信息
    //JLMJ_USER_INFO: 'gameyj_mj/jilin/py/prefabs/jlmj_user_info',
    //聊天
    JLMJ_CHAT: 'gameyj_mj/common/prefabs/mj_chat',
    //解散
    JLMJ_JIESAN: 'gameyj_mj/common/prefabs/jlmj_sponsor_dissolve_view',
    //叫牌信息
    JLMJ_JIAOPAI_INFO: 'gameyj_mj/common/prefabs/mj_jiaoInfo_ui',
    SCMJ_JIAOPAI_INFO: 'gameyj_mj/sichuan/py/prefabs/scmj_jiaoInfo_ui',
    CDMJ_JIAOPAI_INFO: 'gameyj_mj/chengdu/py/prefabs/cdmj_jiaoInfo_ui',
    //小结算
    JLMJ_JIESUAN: 'gameyj_mj/common/prefabs/mj_jiesuan_ui',//小结算

    SCMJ_JIESUAN: 'gameyj_mj/sichuan/py/prefabs/scmj_jiesuan_ui',
    CDMJ_JIESUAN: 'gameyj_mj/chengdu/py/prefabs/cdmj_jiesuan_ui',
    FHMJ_JIESUAN: 'gameyj_mj/fenghua/py/prefabs/fhmj_jiesuan_ui',

    //设置界面
    JLMJ_SHEZHI: 'gameyj_mj/common/prefabs/mj_shezhi_node',
    //弹窗
    JLMJ_TANCHUANG: 'gameyj_common/common_res_from_mj/prefabs/mj_popup_view',
    //右侧弹出菜单,返回-规则-设置
    JLMJ_RIGHT_POP_MENU: 'gameyj_mj/jilin/py/prefabs/jlmj_right_pop_menu',
    //个人信息
    // JLMJ_USERINFO: 'gameyj_mj/jilin/py/prefabs/jlmj_user_info',
    JLMJ_USERINFO: 'gameyj_common/prefab/user_info',
    //花小钱
    JLMJ_XIAOQIAN:'gameyj_common/common_res_from_mj/prefabs/mj_xiaoqian',
    //保底
    JLMJ_BAODI:'gameyj_common/common_res_from_mj/prefabs/mj_baodi',
    //规则box
    JLMJ_GZ_BOX:'gameyj_mj/common/prefabs/mj_guize_box',
    //宝箱
    JLMJ_BAO_XIANG:'gameyj_mj/common/prefabs/mj_baoxiang_task',
    //战绩统计通用资源(大结算)
    MJ_ZHANJITONGJI: 'gameyj_mj/common/prefabs/mj_zhanjitongji',
    //聊天
    COM_CHAT: 'gameyj_common/prefab/chat/com_chat',
    //emoji
    COM_EMOJI: 'gameyj_common/prefab/chat/com_emoji',
    //听选择
    MJ_TINGPAI_INFO: 'gameyj_mj/common/prefabs/mj_tingInfo_ui',
};