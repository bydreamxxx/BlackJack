
    const msg = {};
    var handler = require('cdmj_net_handler_cdmj');
    var recvFuncs = {
        [9800]:{ package_name:'msg', msg_name:'msg_xzmj_start_notice', name:msg.msg_xzmj_start_notice, func:handler.on_msg_xzmj_start_notice, func_name:'on_msg_xzmj_start_notice', logtag:'[9800:msg_xzmj_start_notice ]' },
        [9801]:{ package_name:'msg', msg_name:'peng_card_info', name:msg.peng_card_info, func:handler.on_peng_card_info, func_name:'on_peng_card_info', logtag:'[9801:peng_card_info ]' },
        [9802]:{ package_name:'msg', msg_name:'gang_card_info', name:msg.gang_card_info, func:handler.on_gang_card_info, func_name:'on_gang_card_info', logtag:'[9802:gang_card_info ]' },
        [9803]:{ package_name:'msg', msg_name:'hand_card_info', name:msg.hand_card_info, func:handler.on_hand_card_info, func_name:'on_hand_card_info', logtag:'[9803:hand_card_info ]' },
        [9804]:{ package_name:'msg', msg_name:'xzmj_player_info', name:msg.xzmj_player_info, func:handler.on_xzmj_player_info, func_name:'on_xzmj_player_info', logtag:'[9804:xzmj_player_info ]' },
        [9805]:{ package_name:'msg', msg_name:'msg_xzmj_room_info', name:msg.msg_xzmj_room_info, func:handler.on_msg_xzmj_room_info, func_name:'on_msg_xzmj_room_info', logtag:'[9805:msg_xzmj_room_info ]' },
        [9806]:{ package_name:'msg', msg_name:'msg_xzmj_send_card_broadcast', name:msg.msg_xzmj_send_card_broadcast, func:handler.on_msg_xzmj_send_card_broadcast, func_name:'on_msg_xzmj_send_card_broadcast', logtag:'[9806:msg_xzmj_send_card_broadcast ]' },
        [9807]:{ package_name:'msg', msg_name:'msg_xzmj_lack_color_req', name:msg.msg_xzmj_lack_color_req, func:handler.on_msg_xzmj_lack_color_req, func_name:'on_msg_xzmj_lack_color_req', logtag:'[9807:msg_xzmj_lack_color_req ]' },
        [9808]:{ package_name:'msg', msg_name:'msg_xzmj_lack_color_ret', name:msg.msg_xzmj_lack_color_ret, func:handler.on_msg_xzmj_lack_color_ret, func_name:'on_msg_xzmj_lack_color_ret', logtag:'[9808:msg_xzmj_lack_color_ret ]' },
        [9809]:{ package_name:'msg', msg_name:'msg_xzmj_broadcast_lack', name:msg.msg_xzmj_broadcast_lack, func:handler.on_msg_xzmj_broadcast_lack, func_name:'on_msg_xzmj_broadcast_lack', logtag:'[9809:msg_xzmj_broadcast_lack ]' },
        [9810]:{ package_name:'msg', msg_name:'msg_xzmj_color_info', name:msg.msg_xzmj_color_info, func:handler.on_msg_xzmj_color_info, func_name:'on_msg_xzmj_color_info', logtag:'[9810:msg_xzmj_color_info ]' },
        [9811]:{ package_name:'msg', msg_name:'msg_xzmj_broadcast_lack_color', name:msg.msg_xzmj_broadcast_lack_color, func:handler.on_msg_xzmj_broadcast_lack_color, func_name:'on_msg_xzmj_broadcast_lack_color', logtag:'[9811:msg_xzmj_broadcast_lack_color ]' },
        [9812]:{ package_name:'msg', msg_name:'msg_xzmj_out_card_req', name:msg.msg_xzmj_out_card_req, func:handler.on_msg_xzmj_out_card_req, func_name:'on_msg_xzmj_out_card_req', logtag:'[9812:msg_xzmj_out_card_req ]' },
        [9813]:{ package_name:'msg', msg_name:'msg_xzmj_broadcast_out_card', name:msg.msg_xzmj_broadcast_out_card, func:handler.on_msg_xzmj_broadcast_out_card, func_name:'on_msg_xzmj_broadcast_out_card', logtag:'[9813:msg_xzmj_broadcast_out_card ]' },
        [9814]:{ package_name:'msg', msg_name:'msg_xzmj_respond_notice', name:msg.msg_xzmj_respond_notice, func:handler.on_msg_xzmj_respond_notice, func_name:'on_msg_xzmj_respond_notice', logtag:'[9814:msg_xzmj_respond_notice ]' },
        [9815]:{ package_name:'msg', msg_name:'msg_xzmj_oprate_req', name:msg.msg_xzmj_oprate_req, func:handler.on_msg_xzmj_oprate_req, func_name:'on_msg_xzmj_oprate_req', logtag:'[9815:msg_xzmj_oprate_req ]' },
        [9816]:{ package_name:'msg', msg_name:'msg_xzmj_broadcast_oprate', name:msg.msg_xzmj_broadcast_oprate, func:handler.on_msg_xzmj_broadcast_oprate, func_name:'on_msg_xzmj_broadcast_oprate', logtag:'[9816:msg_xzmj_broadcast_oprate ]' },
        [9817]:{ package_name:'msg', msg_name:'xzmj_player_balance_info', name:msg.xzmj_player_balance_info, func:handler.on_xzmj_player_balance_info, func_name:'on_xzmj_player_balance_info', logtag:'[9817:xzmj_player_balance_info ]' },
        [9818]:{ package_name:'msg', msg_name:'msg_xzmj_result_ret', name:msg.msg_xzmj_result_ret, func:handler.on_msg_xzmj_result_ret, func_name:'on_msg_xzmj_result_ret', logtag:'[9818:msg_xzmj_result_ret ]' },

    };
    module.exports = {
        name:"c_msg_chengdumj_func",
        handler:handler,
        recvFuncs:recvFuncs,
    }
