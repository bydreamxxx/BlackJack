const Prefix = 'resources/gameyj_nn/audio/new/';
module.exports = {
    GAME_MUSIC: Prefix + 'OXqzmusic_game.mp3',
    //特效
    COMMON: {
        START_GAME: Prefix + 'OXqzgame_start.mp3',//开始游戏
        WIN: Prefix + 'OXqzgame_win.mp3',//胜利
        LOSE: Prefix + 'OXqzgame_lost.mp3',//失败
        AllWin: Prefix + 'OxAllWin.mp3',
        AllLose: Prefix + 'OxAllLose.mp3',
        Btn: Prefix + 'OxButton.mp3',//按钮音
        // DEAL_CARD: Prefix + 'pushcard.mp3',//发牌
        // RANDOM_BANKER: Prefix + 'randombanker.mp3',//随机庄
        TIMER: 'resources/gameyj_nn/audio/schtime2.mp3',//倒计时
        // TIMER_1: Prefix + 'schtime2.mp3',//倒计时最后一秒
        BET: Prefix + 'Oxxiazhu.mp3',//下注
        BANKER: Prefix + 'OXqzqiangzhuang.mp3',//定庄
        OpenCard: Prefix + 'OxOpenCard.mp3',//开牌
        GoldFly: Prefix + 'OXqzgold.mp3',//金币
    },
    MAN: {
        //叫分
        QIANGZHUANG: {
            [0]: Prefix + 'Oxbuqiang.mp3',
            [1]: Prefix + 'Oxyibei.mp3',
            [2]: Prefix + 'Oxliangbei.mp3',
            [3]: Prefix + 'Oxsanbei.mp3',
            [4]: Prefix + 'Oxsibei.mp3',
        },
        //牌型
        PAIXING: {
            // [0]: Prefix + 'niu_1_100.mp3',//没牛	
            // [1]: Prefix + 'niu_1_101.mp3',//牛一
            // [2]: Prefix + 'niu_1_102.mp3',//牛二
            // [3]: Prefix + 'niu_1_103.mp3',//牛三
            // [4]: Prefix + 'niu_1_104.mp3',//牛四
            // [5]: Prefix + 'niu_1_105.mp3',//牛五
            // [6]: Prefix + 'niu_1_106.mp3',//牛六
            // [7]: Prefix + 'niu_1_207.mp3',//牛七
            // [8]: Prefix + 'niu_1_208.mp3',//牛八
            // [9]: Prefix + 'niu_1_209.mp3',//牛九
            // [10]: Prefix + 'niu_1_310.mp3',//牛十
            // [21]: Prefix + 'niu_1_416.mp3',//炸弹
            // [22]: Prefix + 'niu_1_418.mp3',//四花牛
            // [23]: Prefix + 'niu_1_415.mp3',//五花牛
            // [24]: Prefix + 'niu_1_414.mp3',//五小牛

            [0]: Prefix + 'OxWuNiu.mp3',
            [1]: Prefix + 'OxNiu1.mp3',
            [2]: Prefix + 'OxNiu2.mp3',
            [3]: Prefix + 'OxNiu3.mp3',
            [4]: Prefix + 'OxNiu4.mp3',
            [5]: Prefix + 'OxNiu5.mp3',
            [6]: Prefix + 'OxNiu6.mp3',
            [7]: Prefix + 'OxNiu7.mp3',
            [8]: Prefix + 'OxNiu8.mp3',
            [9]: Prefix + 'OxNiu9.mp3',
            [10]: Prefix + 'OxNiuNiu.mp3',
            [11]: Prefix + 'Oxsantiao.mp3',
            [14]: Prefix + 'Oxshunzi.mp3',
            [15]: Prefix + 'Oxtonghua.mp3',
            [12]: Prefix + 'OxYinNiu.mp3',
            [16]: Prefix + 'Oxhulu.mp3',
            [13]: Prefix + 'OxJinNiu.mp3',
            [17]: Prefix + 'OxBomb.mp3',
            [19]: Prefix + 'Oxwuxiaoniu.mp3',
            [18]: Prefix + 'Oxtonghuashun.mp3',
        },
    },
    WOMAN: {
        //叫分
        QIANGZHUANG: {
            [0]: Prefix + 'Oxbuqiang.mp3',
            [1]: Prefix + 'Oxyibei.mp3',
            [2]: Prefix + 'Oxliangbei.mp3',
            [3]: Prefix + 'Oxsanbei.mp3',
            [4]: Prefix + 'Oxsibei.mp3',
        },
        //牌型
        PAIXING: {
            // [0]: Prefix + 'niu_2_100.mp3',//没牛	
            // [1]: Prefix + 'niu_2_101.mp3',//牛一
            // [2]: Prefix + 'niu_2_102.mp3',//牛二
            // [3]: Prefix + 'niu_2_103.mp3',//牛三
            // [4]: Prefix + 'niu_2_104.mp3',//牛四
            // [5]: Prefix + 'niu_2_105.mp3',//牛五
            // [6]: Prefix + 'niu_2_106.mp3',//牛六
            // [7]: Prefix + 'niu_2_207.mp3',//牛七
            // [8]: Prefix + 'niu_2_208.mp3',//牛八
            // [9]: Prefix + 'niu_2_209.mp3',//牛九
            // [10]: Prefix + 'niu_2_310.mp3',//牛十
            // [21]: Prefix + 'niu_2_416.mp3',//炸弹
            // [22]: Prefix + 'niu_2_418.mp3',//四花牛
            // [23]: Prefix + 'niu_2_415.mp3',//五花牛
            // [24]: Prefix + 'niu_2_414.mp3',//五小牛

            [0]: Prefix + 'OxWuNiu.mp3',
            [1]: Prefix + 'OxNiu1.mp3',
            [2]: Prefix + 'OxNiu2.mp3',
            [3]: Prefix + 'OxNiu3.mp3',
            [4]: Prefix + 'OxNiu4.mp3',
            [5]: Prefix + 'OxNiu5.mp3',
            [6]: Prefix + 'OxNiu6.mp3',
            [7]: Prefix + 'OxNiu7.mp3',
            [8]: Prefix + 'OxNiu8.mp3',
            [9]: Prefix + 'OxNiu9.mp3',
            [10]: Prefix + 'OxNiuNiu.mp3',
            [11]: Prefix + 'Oxsantiao.mp3',
            [14]: Prefix + 'Oxshunzi.mp3',
            [15]: Prefix + 'Oxtonghua.mp3',
            [12]: Prefix + 'OxYinNiu.mp3',
            [16]: Prefix + 'Oxhulu.mp3',
            [13]: Prefix + 'OxJinNiu.mp3',
            [17]: Prefix + 'OxBomb.mp3',
            [19]: Prefix + 'Oxwuxiaoniu.mp3',
            [18]: Prefix + 'Oxtonghuashun.mp3',
        },
    },
};