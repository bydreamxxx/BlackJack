var HuType = require('jlmj_define').HuType;
var RoomMgr = require('jlmj_room_mgr').RoomMgr;

let base_mj_net_handler_base_mj = require("base_mj_net_handler_base_mj");

const HANDLER_TYPE = {
    JBC: 0,
    FRIEND: 1,
    REPLAY: 2
}

var fz_handler = cc.Class({

    extends: base_mj_net_handler_base_mj.handler,

    ctor: function () {
        cc.log("fhmj_net_handler_fhmj 父类");
    },

    setReconnectRule(rule){
        RoomMgr.Instance()._Rule = rule;
    },

    getJBC(){
        return cc.dd.Define.GameType.FHMJ_GOLD;
    },

    getFriend(){
        return cc.dd.Define.GameType.FHMJ_FRIEND;
    },

    checkSpecialHu(hutype){
        return hutype == HuType.BIAN_HU;
    },

    reconnectCheckHuCardList(msg){
        this.require_UserPlayer.paixu();
    },

    on_mj_ack_game_deal_cards: function( msg ) {
        this.require_UserPlayer.waitTing = false;

        if (!this.headerHandle(msg)) return;
        if(this.require_DeskData.Instance().isInMaJiang()){
            cc.gateNet.Instance().dispatchTimeOut(4);
        }

        this.require_playerMgr.Instance().playing_fapai_ani = true;
        this.require_playerMgr.Instance().setPlayerCardList(msg.playercardList);

        let showFapai = true;
        //如果已经有玩家有摆牌了，就不播动画
        for(let i = 0; i < msg.playercardList.length; i++){
            if(msg.playercardList[i].composecardList.length > 0){
                if(msg.playercardList[i].composecardList.length === 1 && msg.playercardList[i].composecardList[0].type === 12){
                    continue;
                }
                showFapai = false;
                cc.gateNet.Instance().clearDispatchTimeout();

                if(this.require_playerMgr.Instance().playing_fapai_ani){
                    this.stopFaPaiAni();
                }

                break
            }
        }

        if(!cc.replay_gamedata_scrolling){
            var play_list = cc.find('Canvas/player_list').getComponent(this.mjComponentValue.playerList);
            play_list.playerUpdateShouPaiUI();
        }
        this.fapaiAction(showFapai);
    },
    /**
     * 金币场 听牌后更新宝牌
     * @param msg
     */
    on_mj_ack_bao: function (msg) {
        this.require_DeskData.Instance().setBaoPai( msg.card );
        this.require_UserPlayer.paixu();
        if(!cc.replay_gamedata_scrolling){
            cc.find("Canvas/desk_info").getComponent(this.mjComponentValue.deskInfo).updateBaoPai();
            cc.find("Canvas/desk_node/jlmj_player_down_ui").getComponent(this.mjComponentValue.playerDownUI).updateShouPai();
        }
    },

    on_mj_ack_chi: function( msg ) {
        if (!this.headerHandle(msg)) return;
        //被吃的牌，移除
        var playerOut = this.require_playerMgr.Instance().getPlayer(msg.useridout);
        let viewIdx = 0;
        if (playerOut) {
            viewIdx = playerOut.viewIdx;
            playerOut.beichi();
        }

        //吃的牌，移除
        var playerIn = this.require_playerMgr.Instance().getPlayer(msg.useridin);
        if (playerIn) {
            playerIn.chi(msg.chicardList, viewIdx);
        }

        if(!cc.replay_gamedata_scrolling){
            this.require_playerMgr.Instance().shou2mid_id_list.pop();
            //吃 碰 杠 胡 出牌,停止出牌动画
            var play_list = cc.find('Canvas/player_list');
            if(play_list){
                play_list.getComponent(this.mjComponentValue.playerList).playerStopChuPaiAni();
            }
            cc.log('停止出牌动画-吃牌');
        }

        this.require_DeskED.notifyEvent(this.require_DeskEvent.CLOSE_MENU, []);
        if(!this.require_DeskData.Instance().dabaoing){
            this.require_DeskED.notifyEvent(this.require_DeskEvent.BIAOJI_BAOPAI,[]);
        }

        var player_down_ui = cc.find("Canvas/desk_node/jlmj_player_down_ui").getComponent(this.mjComponentValue.playerDownUI);
        player_down_ui.setShoupaiTingbiaoji(false);
        this.require_UserPlayer.clearJiaoPaiMsg();
        cc.dd.NetWaitUtil.net_wait_end();

        if(!this._chipengList.hasOwnProperty(msg.useridout)){
            this._chipengList[msg.useridout] = {};
        }
        let player = this._chipengList[msg.useridout];
        if(!player.hasOwnProperty(msg.useridin)){
            player[msg.useridin] = 0;
        }
        player[msg.useridin]++;

        if(player[msg.useridin] >= 2 && this.handlerType != HANDLER_TYPE.REPLAY){
            if(msg.useridout == cc.dd.user.id || msg.useridin == cc.dd.user.id){
                cc.find("Canvas/desk_info").getComponent(this.mjComponentValue.deskInfo).showChiPengTips(player[msg.useridin]);
            }
        }
    },

    on_mj_ack_game_act_peng: function( msg ) {
        if (!this.headerHandle(msg)) return;
        //被碰的牌，移除
        var playerOut = this.require_playerMgr.Instance().getPlayer(msg.useridout);
        let viewIdx = 0;
        if (playerOut) {
            viewIdx = playerOut.viewIdx;
            if (msg.isrob) {
                playerOut.beiQiangPeng();
            } else {
                playerOut.beipeng();
            }
        }

        //碰的牌，移除
        var playerIn = this.require_playerMgr.Instance().getPlayer(msg.useridin);
        if (playerIn) {
            playerIn.peng(msg.pengcardList, viewIdx);
        }

        if(!cc.replay_gamedata_scrolling){
            this.require_playerMgr.Instance().shou2mid_id_list.pop();
            //吃 碰 杠 胡 出牌,停止出牌动画
            var play_list = cc.find('Canvas/player_list');
            if(play_list){
                play_list.getComponent(this.mjComponentValue.playerList).playerStopChuPaiAni();
            }
            cc.log('停止出牌动画-碰牌');
        }

        this.require_DeskED.notifyEvent(this.require_DeskEvent.CLOSE_MENU, []);
        if(!this.require_DeskData.Instance().dabaoing){
            this.require_DeskED.notifyEvent(this.require_DeskEvent.BIAOJI_BAOPAI,[]);
        }

        var player_down_ui = cc.find("Canvas/desk_node/jlmj_player_down_ui").getComponent(this.mjComponentValue.playerDownUI);
        player_down_ui.setShoupaiTingbiaoji(false);
        this.require_UserPlayer.clearJiaoPaiMsg();
        cc.dd.NetWaitUtil.net_wait_end();

        if(!this._chipengList.hasOwnProperty(msg.useridout)){
            this._chipengList[msg.useridout] = {};
        }
        let player = this._chipengList[msg.useridout];
        if(!player){
            this._chipengList[msg.useridout] = {}
        }
        if(!player.hasOwnProperty(msg.useridin)){
            player[msg.useridin] = 0;
        }
        player[msg.useridin]++;

        if(player[msg.useridin] >= 2 && this.handlerType != HANDLER_TYPE.REPLAY){
            if(msg.useridout == cc.dd.user.id || msg.useridin == cc.dd.user.id){
                cc.find("Canvas/desk_info").getComponent(this.mjComponentValue.deskInfo).showChiPengTips(player[msg.useridin]);
            }
        }
    },

    on_mj_ack_game_act_gang: function( msg ) {
        if (!this.headerHandle(msg)) return;
        var playerOut = this.require_playerMgr.Instance().getPlayer(msg.useridout);
        let viewIdx = playerOut.viewIdx;
        if (msg.isrob) {
            playerOut.beiQiangGang();
        } else {
            if (msg.gangtype == 1 || msg.gangtype == 8 || msg.gangtype == 10 ||
                msg.gangtype == 12 || msg.gangtype == 14 || msg.gangtype == 16) {
                //点杠 被杠的牌，移除
                playerOut.beigang();
            }
        }

        //玩家杠
        var playerIn = this.require_playerMgr.Instance().getPlayer(msg.useridin);
        if (playerIn) {
            playerIn.gang(msg, viewIdx);
        }
        if(msg.useridin == cc.dd.user.id){
            this.require_UserPlayer.modepai = null;
        }
        if(!cc.replay_gamedata_scrolling){
            this.require_playerMgr.Instance().shou2mid_id_list.pop();
            //吃 碰 杠 胡 出牌,停止出牌动画
            var play_list = cc.find('Canvas/player_list');
            if(play_list){
                play_list.getComponent(this.mjComponentValue.playerList).playerStopChuPaiAni();
            }
            cc.log('停止出牌动画-杠牌');
        }

        this.require_DeskED.notifyEvent(this.require_DeskEvent.CLOSE_MENU, []);
        if(!this.require_DeskData.Instance().dabaoing){
            this.require_DeskED.notifyEvent(this.require_DeskEvent.BIAOJI_BAOPAI,[]);
        }

        var player_down_ui = cc.find("Canvas/desk_node/jlmj_player_down_ui").getComponent(this.mjComponentValue.playerDownUI);
        player_down_ui.setShoupaiTingbiaoji(false);
        this.require_UserPlayer.clearJiaoPaiMsg();
        cc.dd.NetWaitUtil.net_wait_end();
    },

    on_mj_ack_roomInit: function( msg ) {
        this.require_DeskData.Instance().showGuo = true;
        this._super(msg);
        this._chipengList = {};
    },

    on_mj_ack_reconnect: function( msg ) {
        this._super(msg);

        this._chipengList = {};

        msg.playerinfoList.forEach(player=>{
            let cardList = player.playercard.composecardList;
            cardList.forEach(card=>{
                if(card.type == 7 || card.type == 8){
                    if(!this._chipengList.hasOwnProperty(card.useridout)){
                        this._chipengList[card.useridout] = {};
                    }
                    let _player = this._chipengList[card.useridout];
                    if(!_player.hasOwnProperty(player.userid)){
                        _player[player.userid] = 0;
                    }
                    _player[player.userid]++;
                }
            })
        })
    },

    on_mj_ack_game_send_out_card: function( msg ) {
        this.require_DeskData.Instance().waitForSendOutCard = false;

        if (!this.headerHandle(msg)) {
            this.require_DeskData.Instance().sendCard = null;

            if(msg.userid == cc.dd.user.id && msg.card && this.realCardID && msg.card.id != this.realCardID[msg.userid]){
                let player = this.require_playerMgr.Instance().getPlayer(msg.userid);
                if(player.shoupai.indexOf(msg.card.id) == -1) {
                    var player_down_ui = cc.find("Canvas/desk_node/jlmj_player_down_ui").getComponent(this.mjComponentValue.playerDownUI);
                    player_down_ui.stopChuPai();

                    player.addShouPai([msg.card.id]);
                    player.paixu();
                    let idx = player.chupai.indexOf(msg.card.id);
                    if(idx != -1){
                        player.chupai.splice(idx, 1);
                    }

                    player_down_ui.removeChupai(player);
                    player_down_ui.updateShouPai();

                    // if(cc.dd._.isArray(this.require_UserPlayer.waitDapai) && this.require_UserPlayer.waitDapai.length > 0){
                    //     let pai = this.require_UserPlayer.waitDapai.shift();
                    //     this.require_playerMgr.Instance().shou2mid_id_list.push(pai);
                    //     this.require_UserPlayer.dapai(pai);
                    // }
                }
            }
            cc.dd.NetWaitUtil.net_wait_end();
            return;
        }

        if(!this.realCardID){
            this.realCardID = {};
        }
        this.realCardID[msg.userid] = msg.card.id;

        if(cc.dd.user.id == msg.userid){
            this.require_UserPlayer.setJiaoInfo(msg.card.id);
        }
        if(cc.dd.user.id == msg.userid){
            var player_down_ui = cc.find("Canvas/desk_node/jlmj_player_down_ui").getComponent(this.mjComponentValue.playerDownUI);
            player_down_ui.setShoupaiTingbiaoji(false);
        }
        var func = () => {
            var player = this.require_playerMgr.Instance().getPlayer(msg.userid);
            if (player) {
                if(msg.hasOwnProperty('othertipsList')){
                    let isQuick = true;

                    for(let i = 0; i < msg.othertipsList.length; i++){
                        let item = msg.othertipsList[i];
                        if(item.canchi || item.canpeng || item.cangang || item.canhu){
                            isQuick = false;
                            break;
                        }
                    }

                    this.require_playerMgr.Instance().shou2mid_id_list.push(msg.card.id);
                    if(msg.userid != cc.dd.user.id || ((player.isBaoTing || this.require_UserPlayer.waitTing || this.require_DeskData.Instance().isoffline) && player.chupai.indexOf(msg.card.id) == -1) || player.replaying || player.shoupai.indexOf(msg.card.id) != -1){
                        // if(msg.userid == cc.dd.user.id && UserPlayer.mid2dapai_playing){
                        //     if(!cc.dd._.isArray(UserPlayer.waitDapai)){
                        //         UserPlayer.waitDapai = [];
                        //     }
                        //     UserPlayer.waitDapai.push(msg.card.id);
                        // }else{
                        player.dapai(msg.card.id, isQuick);
                        // }
                    }

                }else{
                    if(msg.userid != cc.dd.user.id || ((player.isBaoTing || this.require_UserPlayer.waitTing || this.require_DeskData.Instance().isoffline) && player.chupai.indexOf(msg.card.id) == -1) || player.replaying || player.shoupai.indexOf(msg.card.id) != -1){
                        // if(msg.userid == cc.dd.user.id && this.require_UserPlayer.mid2dapai_playing){
                        //     if(!cc.dd._.isArray(this.require_UserPlayer.waitDapai)){
                        //         this.require_UserPlayer.waitDapai = [];
                        //     }
                        //     this.require_UserPlayer.waitDapai.push(msg.card.id);
                        // }else{
                        this.require_playerMgr.Instance().shou2mid_id_list.push(msg.card.id);
                        player.dapai(msg.card.id);
                        // }
                    }
                }


            }
            if(msg.userid == cc.dd.user.id){
                this.require_UserPlayer.waitTing = false;
            }

            this.require_DeskData.Instance().last_chupai_id = msg.card.id;
            if(!this.require_DeskData.Instance().dabaoing){
                this.require_DeskED.notifyEvent(this.require_DeskEvent.BIAOJI_BAOPAI,[]);
            }
            this.require_playerMgr.Instance().chupai_timeout_on_ting = false;
        };

        //听牌后的出牌延时
        if(this.require_playerMgr.Instance().chupai_timeout_on_ting){
            setTimeout(function () {
                func();
            }.bind(this),300);
        }else{
            func();
        }
        this.require_DeskED.notifyEvent(this.require_DeskEvent.STOP_TIMEUP,[]);
        cc.dd.NetWaitUtil.net_wait_end();
    },

    setReconnectRule(rule){
        RoomMgr.Instance()._Rule = rule;
        if(this.require_DeskData.Instance().isPassMatch()){
            this.require_deskJBCData.getInstance().setBaseScore(rule.reservedList[0]);
        }
    },

    initMJComponet(){
        return require("mjComponentValue").fhmj;
    },
});

module.exports = new fz_handler();