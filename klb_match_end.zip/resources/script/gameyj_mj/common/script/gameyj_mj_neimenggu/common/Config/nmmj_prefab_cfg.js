
module.exports = {
    //第几圈
    JLMJ_TIPS_POP: 'gameyj_mj_neimenggu/common/prefabs/nmmj_tips_pop',
    //解散
    JLMJ_JIESAN: 'gameyj_mj_neimenggu/common/prefabs/nmmj_sponsor_dissolve_view',
    //叫牌信息
    JLMJ_JIAOPAI_INFO: 'gameyj_mj_neimenggu/common/prefabs/nmmj_jiaoInfo_ui',
    //小结算
    JLMJ_JIESUAN: 'gameyj_mj_neimenggu/common/prefabs/nmmj_jiesuan_ui',//小结算
    //设置界面
    JLMJ_SHEZHI: 'gameyj_mj_neimenggu/common/prefabs/nmmj_shezhi_node',
    //弹窗
    JLMJ_TANCHUANG: 'gameyj_mj_neimenggu/common/prefabs/nmmj_popup_view',
    //个人信息
    JLMJ_USERINFO: 'gameyj_mj_neimenggu/common/prefabs/nmmj_user_info',
    //花小钱
    JLMJ_XIAOQIAN:'gameyj_common/common_res_from_mj/prefabs/mj_xiaoqian',
    //保底
    JLMJ_BAODI:'gameyj_common/common_res_from_mj/prefabs/mj_baodi',
    //规则box
    JLMJ_GZ_BOX:'gameyj_mj_neimenggu/common/prefabs/nmmj_guize_box',
    //战绩统计通用资源(大结算)
    MJ_ZHANJITONGJI: 'gameyj_mj_neimenggu/common/prefabs/nmmj_zhanjitongji',
    //聊天
    COM_CHAT: 'gameyj_common/prefab/chat/com_chat',
    //聊天
    NMMJ_GPS: 'gameyj_mj_neimenggu/common/prefabs/nmmj_gps',
};