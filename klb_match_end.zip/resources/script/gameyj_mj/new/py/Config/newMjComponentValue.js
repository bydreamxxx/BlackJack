let newMjComponentValue = {
    new_mj:{
        zhinan: 'new_mj_zhinan_ui',
        playerList: 'new_mj_player_list',
        playerUI: 'new_mj_player_base_ui',
        userData: 'new_mj_userPlayer_data',
        mjZhuobu: 'new_mj_zhuobu_set_',
        deskData: 'new_mj_desk_data',
        paiAnalysts: 'new_mj_pai_analysts',
        playerMgr: 'new_mj_player_mgr',
        zhiNanUI: 'new_mj_zhinan_ui',
        jieSanData: 'new_mj_jiesan_data',
        mjUtil: 'new_mj_util',
        deskJBCData: 'new_mj_desk_data_jbc',
        playerData: 'new_mj_player_data',
        controlCombination: 'new_mj_Control_Combination_ui',
        gameMenu: 'new_mj_game_menu',
        gameMenuList: 'new_mj_game_menu_list',
        createRoom: 'new_mj_createRoom',
        scene: 'new_mj_scene',
        playerHead: 'new_mj_playerHead',
        deskInfo: 'new_mj_desk_info'
    },

    cdmj:{
        zhinan: 'cdmj_zhinan_ui',
        playerList: 'cdmj_player_list',
        playerUI: 'cdmj_player_base_ui',
        userData: 'cdmj_userPlayer_data',
        mjZhuobu: 'cdmj_zhuobu_set_',
        deskData: 'cdmj_desk_data',
        paiAnalysts: 'cdmj_pai_analysts',
        playerMgr: 'cdmj_player_mgr',
        zhiNanUI: 'cdmj_zhinan_ui',
        jieSanData: 'cdmj_jiesan_data',
        mjUtil: 'cdmj_util',
        deskJBCData: 'cdmj_desk_data_jbc',
        playerData: 'cdmj_player_data',
        controlCombination: 'cdmj_Control_Combination_ui',
        gameMenu: 'cdmj_game_menu',
        gameMenuList: 'cdmj_game_menu_list',
        createRoom: 'cdmj_createRoom',
        scene: 'cdmj_scene',
        playerHead: 'cdmj_playerHead',
        deskInfo: 'cdmj_desk_info'
    }
}

module.exports=newMjComponentValue;