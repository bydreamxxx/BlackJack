var data_welfareBag =
{
    items:
    [
      { key:2,level:1,type:6,sub_type:0,icon_type:10,task_id:28,title:"25元宝" },
      { key:3,level:1,type:1,sub_type:0,icon_type:1,task_id:0,title:"首充礼包" },
      { key:4,level:1,type:2,sub_type:1,icon_type:7,task_id:0,title:"幸运抽奖" },
      { key:5,level:1,type:3,sub_type:3,icon_type:5,task_id:1,title:"每日分享" },
      { key:6,level:1,type:7,sub_type:4,icon_type:13,task_id:48,title:"月卡礼包" },
      { key:7,level:2,type:6,sub_type:0,icon_type:10,task_id:29,title:"40元宝" },
      { key:8,level:2,type:1,sub_type:0,icon_type:1,task_id:0,title:"首充礼包" },
      { key:9,level:2,type:2,sub_type:1,icon_type:7,task_id:0,title:"幸运抽奖" },
      { key:10,level:2,type:3,sub_type:3,icon_type:5,task_id:1,title:"每日分享" },
      { key:11,level:2,type:6,sub_type:3,icon_type:12,task_id:37,title:"1.0元红包券" },
      { key:12,level:2,type:7,sub_type:4,icon_type:13,task_id:48,title:"月卡礼包" },
      { key:13,level:3,type:6,sub_type:0,icon_type:10,task_id:30,title:"50元宝" },
      { key:14,level:3,type:1,sub_type:0,icon_type:1,task_id:0,title:"首充礼包" },
      { key:15,level:3,type:2,sub_type:1,icon_type:7,task_id:0,title:"幸运抽奖" },
      { key:16,level:3,type:3,sub_type:3,icon_type:5,task_id:1,title:"每日分享" },
      { key:17,level:3,type:6,sub_type:3,icon_type:12,task_id:38,title:"1.0元红包券" },
      { key:18,level:3,type:7,sub_type:4,icon_type:13,task_id:48,title:"月卡礼包" },
      { key:19,level:4,type:6,sub_type:0,icon_type:10,task_id:31,title:"60元宝" },
      { key:20,level:4,type:1,sub_type:0,icon_type:1,task_id:0,title:"首充礼包" },
      { key:21,level:4,type:2,sub_type:1,icon_type:7,task_id:0,title:"幸运抽奖" },
      { key:22,level:4,type:3,sub_type:3,icon_type:5,task_id:1,title:"每日分享" },
      { key:23,level:4,type:6,sub_type:3,icon_type:12,task_id:39,title:"2.0元红包券" },
      { key:24,level:4,type:7,sub_type:4,icon_type:13,task_id:48,title:"月卡礼包" },
      { key:25,level:5,type:6,sub_type:0,icon_type:10,task_id:32,title:"80元宝" },
      { key:26,level:5,type:1,sub_type:0,icon_type:1,task_id:0,title:"首充礼包" },
      { key:27,level:5,type:2,sub_type:1,icon_type:7,task_id:0,title:"幸运抽奖" },
      { key:28,level:5,type:3,sub_type:3,icon_type:5,task_id:1,title:"每日分享" },
      { key:29,level:5,type:6,sub_type:3,icon_type:12,task_id:40,title:"2.0元红包券" },
      { key:30,level:5,type:7,sub_type:4,icon_type:13,task_id:48,title:"月卡礼包" },
      { key:31,level:6,type:6,sub_type:0,icon_type:10,task_id:33,title:"100元宝" },
      { key:32,level:6,type:1,sub_type:0,icon_type:1,task_id:0,title:"首充礼包" },
      { key:33,level:6,type:2,sub_type:1,icon_type:7,task_id:0,title:"幸运抽奖" },
      { key:34,level:6,type:3,sub_type:3,icon_type:5,task_id:1,title:"每日分享" },
      { key:35,level:6,type:6,sub_type:3,icon_type:12,task_id:41,title:"3.0元红包券" },
      { key:36,level:6,type:7,sub_type:4,icon_type:13,task_id:48,title:"月卡礼包" },
      { key:37,level:7,type:6,sub_type:0,icon_type:10,task_id:34,title:"150元宝" },
      { key:38,level:7,type:1,sub_type:0,icon_type:1,task_id:0,title:"首充礼包" },
      { key:39,level:7,type:2,sub_type:1,icon_type:7,task_id:0,title:"幸运抽奖" },
      { key:40,level:7,type:3,sub_type:3,icon_type:5,task_id:1,title:"每日分享" },
      { key:41,level:7,type:6,sub_type:3,icon_type:12,task_id:42,title:"3.0元红包券" },
      { key:42,level:7,type:7,sub_type:4,icon_type:13,task_id:48,title:"月卡礼包" },
      { key:43,level:8,type:6,sub_type:0,icon_type:10,task_id:35,title:"200元宝" },
      { key:44,level:8,type:1,sub_type:0,icon_type:1,task_id:0,title:"首充礼包" },
      { key:45,level:8,type:2,sub_type:1,icon_type:7,task_id:0,title:"幸运抽奖" },
      { key:46,level:8,type:3,sub_type:3,icon_type:5,task_id:1,title:"每日分享" },
      { key:47,level:8,type:6,sub_type:3,icon_type:12,task_id:43,title:"4.0元红包券" },
      { key:48,level:8,type:7,sub_type:4,icon_type:13,task_id:48,title:"月卡礼包" },
      { key:49,level:9,type:6,sub_type:0,icon_type:10,task_id:36,title:"300元宝" },
      { key:50,level:9,type:1,sub_type:0,icon_type:1,task_id:0,title:"首充礼包" },
      { key:51,level:9,type:2,sub_type:1,icon_type:7,task_id:0,title:"幸运抽奖" },
      { key:52,level:9,type:3,sub_type:3,icon_type:5,task_id:1,title:"每日分享" },
      { key:53,level:9,type:6,sub_type:3,icon_type:12,task_id:44,title:"4.0元红包券" },
      { key:54,level:9,type:7,sub_type:4,icon_type:13,task_id:48,title:"月卡礼包" },
      { key:55,level:10,type:1,sub_type:0,icon_type:1,task_id:0,title:"首充礼包" },
      { key:56,level:10,type:2,sub_type:1,icon_type:7,task_id:0,title:"幸运抽奖" },
      { key:57,level:10,type:3,sub_type:3,icon_type:5,task_id:1,title:"每日分享" },
      { key:58,level:10,type:6,sub_type:3,icon_type:12,task_id:45,title:"5.0元红包券" },
      { key:59,level:10,type:7,sub_type:4,icon_type:13,task_id:48,title:"月卡礼包" },
      { key:60,level:1,type:6,sub_type:3,icon_type:10,task_id:57,title:"5元宝" },
      { key:61,level:2,type:6,sub_type:3,icon_type:10,task_id:58,title:"5元宝" },
      { key:62,level:3,type:6,sub_type:3,icon_type:10,task_id:59,title:"5元宝" },
      { key:63,level:4,type:6,sub_type:3,icon_type:10,task_id:60,title:"5元宝" },
      { key:64,level:5,type:6,sub_type:3,icon_type:10,task_id:61,title:"5元宝" },
      { key:65,level:6,type:6,sub_type:3,icon_type:10,task_id:62,title:"5元宝" },
      { key:66,level:7,type:6,sub_type:3,icon_type:10,task_id:63,title:"5元宝" },
      { key:67,level:8,type:6,sub_type:3,icon_type:10,task_id:64,title:"5元宝" },
      { key:68,level:9,type:6,sub_type:3,icon_type:10,task_id:65,title:"5元宝" },
      { key:69,level:10,type:6,sub_type:3,icon_type:10,task_id:66,title:"5元宝" },
      { key:70,level:1,type:6,sub_type:3,icon_type:10,task_id:67,title:"10元宝" },
      { key:71,level:2,type:6,sub_type:3,icon_type:10,task_id:68,title:"10元宝" },
      { key:72,level:3,type:6,sub_type:3,icon_type:10,task_id:69,title:"10元宝" },
      { key:73,level:4,type:6,sub_type:3,icon_type:10,task_id:70,title:"10元宝" },
      { key:74,level:5,type:6,sub_type:3,icon_type:10,task_id:71,title:"10元宝" },
      { key:75,level:6,type:6,sub_type:3,icon_type:10,task_id:72,title:"15元宝" },
      { key:76,level:7,type:6,sub_type:3,icon_type:10,task_id:73,title:"15元宝" },
      { key:77,level:8,type:6,sub_type:3,icon_type:10,task_id:74,title:"15元宝" },
      { key:78,level:9,type:6,sub_type:3,icon_type:10,task_id:75,title:"15元宝" },
      { key:79,level:10,type:6,sub_type:3,icon_type:10,task_id:76,title:"15元宝" },
      { key:80,level:1,type:6,sub_type:3,icon_type:12,task_id:77,title:"0.5元红包券" },
      { key:81,level:2,type:6,sub_type:3,icon_type:12,task_id:78,title:"0.5元红包券" },
      { key:82,level:3,type:6,sub_type:3,icon_type:12,task_id:79,title:"0.5元红包券" },
      { key:83,level:4,type:6,sub_type:3,icon_type:12,task_id:80,title:"1.0元红包券" },
      { key:84,level:5,type:6,sub_type:3,icon_type:12,task_id:81,title:"1.0元红包券" },
      { key:85,level:6,type:6,sub_type:3,icon_type:12,task_id:82,title:"1.0元红包券" },
      { key:86,level:7,type:6,sub_type:3,icon_type:12,task_id:83,title:"2.0元红包券" },
      { key:87,level:8,type:6,sub_type:3,icon_type:12,task_id:84,title:"2.0元红包券" },
      { key:88,level:9,type:6,sub_type:3,icon_type:12,task_id:85,title:"2.0元红包券" },
      { key:89,level:10,type:6,sub_type:3,icon_type:12,task_id:86,title:"2.0元红包券" }
    ],

    /**
     * 查找第一个符合filter的item
     * @param filter
     * @returns {*}
     */
    getItem: function(filter){
        var result = null;
        for(var i=0; i<this.items.length; ++i){
            if(filter(this.items[i])){
                result = this.items[i];
                return result;
            }
        }
        return result;
    },

    /**
     * 查找第一个符合filter的list
     * @param filter
     * @returns {*}
     */
    getItemList: function(filter){
        var list = [];
        this.items.forEach(function (item) {
            if(filter(item)){
                list.push(item);
            }
        });
        return list;
    },
};

module.exports=data_welfareBag;